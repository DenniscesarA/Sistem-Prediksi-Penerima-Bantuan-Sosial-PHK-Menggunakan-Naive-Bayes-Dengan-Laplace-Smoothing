# **Cara install**

```bash
pip install gradio pandas numpy scikit-learn matplotlib seaborn mysql-connector-python sqlalchemy reportlab watchdog openpyxl
```

# **Cara menjalankan aplikasi**

 Jalankan aplikasi dengan perintah berikut: 
```bash
python setup_db.py
```
dan untuk reload otomatis
```bash
watchmedo auto-restart --directory=. --pattern="*.py" --recursive -- python app.py
```


Aplikasi akan berjalan di browser dengan dua URL:
- **Local URL:** http://localhost:7860 (untuk akses lokal)
- **Public URL:** Gradio akan memberikan link publik yang bisa diakses dari internet


## Akun Dummy (untuk login)
| Username     | Password       | Role         |
|--------------|----------------|--------------|
| pegawai      | pegawai123     | pegawai      |
| kepala       | kepala123      | kepala       |

 