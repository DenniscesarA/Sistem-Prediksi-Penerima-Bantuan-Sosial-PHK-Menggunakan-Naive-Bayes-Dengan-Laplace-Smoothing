-- SQL untuk inisialisasi database PKH
CREATE DATABASE IF NOT EXISTS pkh_db;
USE pkh_db;

-- Tabel masyarakat
CREATE TABLE IF NOT EXISTS masyarakat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    pekerjaan_ayah VARCHAR(50) NOT NULL,
    jumlah_anak INT NOT NULL,
    ibu_hamil TINYINT NOT NULL,
    disabilitas TINYINT NOT NULL,
    lansia TINYINT NOT NULL,
    kategori VARCHAR(20) NOT NULL
);

-- Tabel prediksi
CREATE TABLE IF NOT EXISTS prediksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    pekerjaan_ayah VARCHAR(50) NOT NULL,
    jumlah_anak INT NOT NULL,
    ibu_hamil TINYINT NOT NULL,
    disabilitas TINYINT NOT NULL,
    lansia TINYINT NOT NULL,
    hasil VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    label_aktual VARCHAR(20),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- (Opsional) Tabel users jika ingin login dari database
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL
);

-- (Opsional) Data dummy user
INSERT IGNORE INTO users (username, password, role) VALUES
('pegawai', 'pegawai123', 'pegawai'),
('kepala', 'kepala123', 'kepala'); 

-- Seeder data masyarakat
INSERT INTO masyarakat (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori) VALUES
('Nurjanah', 'Karyawan',2,1,1,1, 'Dapat'),
('Tuti Rohani', 'Buruh',2,1,1,1, 'Dapat'),
('Yanti Susanti', 'Mengurus Rumah Tangga',2,1,1,1, 'Tidak dapat'),
('Wawan Hermawan', 'Karyawan',3,1,1,1, 'Tidak dapat'),
('Aris Setiadi', 'Buruh',0,1,1,1, 'Tidak dapat'),
('Nurhayati', 'Buruh',1,1,1,1, 'Dapat'),
('Nurhandayani', 'Buruh',1,1,1,2, 'Dapat'),
('Fedro Kusando', 'Karyawan',2,1,1,2, 'Dapat'),
('Widiyawati', 'Buruh',1,1,1,1, 'Dapat'),
('Sri Mulyanti', 'Buruh',1,1,1,1, 'Tidak dapat'),
('Acah', 'Buruh',1,1,2,2, 'Dapat'),
('Nenti', 'Mengurus Rumah Tangga',0,1,1,2, 'Tidak dapat'),
('David Abdurrokhman', 'Karyawan',2,1,1,1, 'Dapat'),
('Supriyatin', 'Karyawan',2,1,1,1, 'Tidak dapat'),
('Wardi', 'Buruh',4,1,2,1, 'Dapat'),
('Sucipto', 'Tidak Bekerja',2,1,1,1, 'Dapat'),
('Kusnun Rukmana', 'Buruh',1,1,1,1, 'Dapat'),
('Maedi', 'Karyawan',2,1,1,1, 'Dapat'),
('Ubaidillah', 'Tidak Bekerja',2,1,1,1, 'Dapat'),
('Agung Suswati', 'Buruh',1,1,1,1, 'Dapat'),
('Abdul Kosim', 'Buruh',0,1,1,1, 'Tidak dapat'),
('Ahmad Rosul', 'Buruh',0,1,1,2, 'Dapat'),
('Abdurachman', 'Karyawan',1,1,1,1, 'Dapat'),
('Ahmad Jaeni', 'Karyawan',0,1,1,1, 'Tidak dapat'),
('Bambang Heryanto', 'Buruh',0,1,1,2, 'Dapat'),
('Zulkarnain', 'Karyawan',0,1,1,1, 'Tidak dapat'),
('Ratna Agustin Kosasih', 'Mengurus Rumah Tangga',0,2,1,2, 'Dapat'),
('Siti Masniah', 'Mengurus Rumah Tangga',0,1,1,2, 'Dapat'),
('Karyati', 'Mengurus Rumah Tangga',0,1,1,2, 'Dapat'),
('Umamah', 'Buruh',0,1,2,2, 'Dapat'),
('Sonny Franciscus', 'Buruh',2,1,1,1, 'Tidak dapat'),
('Asih', 'Buruh',0,1,1,2, 'Dapat'),
('Amah', 'Buruh',0,1,1,1, 'Tidak dapat'),
('Maunah', 'Mengurus Rumah Tangga',0,1,1,2, 'Dapat'),
('Wasta', 'Buruh',0,1,1,1, 'Tidak dapat'),
('Mini', 'Mengurus Rumah Tangga',0,1,1,1, 'Tidak dapat'),
('Hasanah', 'Buruh',2,1,1,2, 'Dapat'),
('Ahmad Munir', 'Buruh',0,1,1,1, 'Tidak dapat'),
('Uun', 'Mengurus Rumah Tangga',0,1,1,2, 'Dapat'),
('Sumah', 'Mengurus Rumah Tangga',0,1,1,2, 'Dapat'),
('Sumiati', 'Buruh',3,1,1,1, 'Dapat'),
('Syahril Priatna', 'Karyawan',2,1,1,1, 'Dapat'),
('Sadirin', 'Pengusaha',3,1,1,1, 'Dapat'),
('Naryie Elisatari', 'Mengurus Rumah Tangga',1,1,1,2, 'Dapat'),
('Sri Badian', 'Mengurus Rumah Tangga',3,1,1,1, 'Tidak dapat'),
('Nani Sugiarti', 'Buruh',1,1,1,2, 'Dapat'),
('Yogi Siswandi', 'Karyawan',1,1,1,1, 'Tidak dapat'),
('Wartini', 'Mengurus Rumah Tangga',1,1,1,2, 'Dapat'),
('Lukmanul Hakim', 'Pengusaha',3,1,1,1, 'Tidak dapat'),
('Sulaiman', 'Pengusaha',3,1,1,1, 'Tidak dapat'),
('Mini', 'Mengurus Rumah Tangga',0,1,1,1, 'Tidak dapat'),
('Irwan Atmawijaya', 'Karyawan',1,1,1,1, 'Dapat'),
('Eko Faturohman', 'Karyawan',3,1,1,1, 'Dapat'),
('Abdullatif', 'Pengusaha',3,1,1,1, 'Tidak dapat'),
('Rohyatun', 'Mengurus Rumah Tangga',1,1,1,2, 'Dapat'),
('Kasinah', 'Mengurus Rumah Tangga',2,1,1,2, 'Dapat'),
('Dasmi', 'Buruh',0,1,1,2, 'Dapat'),
('Prona Parsulian', 'Karyawan',2,1,1,1, 'Tidak dapat'),
('Peto Suparto', 'Karyawan',0,1,2,1, 'Dapat'),
('Sarini', 'Mengurus Rumah Tangga',2,1,2,1, 'Dapat'),
('Anton Rahmat', 'Karyawan',2,1,1,1, 'Tidak dapat'),
('Intan Desvita', 'Mengurus Rumah Tangga',4,1,1,1, 'Dapat'),
('Defri Maulana', 'Karyawan',2,1,1,1, 'Tidak dapat'),
('Budi Wahyono', 'Karyawan',2,1,2,2, 'Tidak dapat'),
('Rio Junaidi', 'Karyawan',2,1,1,1, 'Tidak dapat'),
('Yanti Susanti', 'Mengurus Rumah Tangga',2,1,2,1, 'Tidak dapat'),
('Wira Pranata', 'Buruh',2,1,1,1, 'Tidak dapat'),
('Sri Hastuti', 'Mengurus Rumah Tangga',0,1,1,1, 'Tidak dapat'),
('Adris Tamaka', 'Karyawan',2,1,1,1, 'Dapat'),
('Ramin Tawab', 'Karyawan',0,1,1,1, 'Dapat'),
('Kurdin Sofyan', 'Buruh',3,1,1,1, 'Dapat'),
('Heri Sukisno', 'Karyawan',3,1,1,1, 'Tidak dapat'); 
