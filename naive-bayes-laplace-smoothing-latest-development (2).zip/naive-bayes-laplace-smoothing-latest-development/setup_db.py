#!/usr/bin/env python3
"""
Script untuk setup database MySQL secara otomatis
"""

import mysql.connector
from mysql.connector import Error
import os

# Konfigurasi database
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'port': 3306
}

def check_mysql_connection():
    """Cek apakah MySQL server berjalan"""
    try:
        conn = mysql.connector.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            port=DB_CONFIG['port']
        )
        print("✅ Koneksi ke MySQL berhasil")
        conn.close()
        return True
    except Error as e:
        print(f"❌ Error koneksi MySQL: {e}")
        print("Pastikan MySQL server sudah berjalan")
        return False

def create_database():
    """Buat database pkh_db jika belum ada"""
    try:
        conn = mysql.connector.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            port=DB_CONFIG['port']
        )
        cursor = conn.cursor()
        
        # Buat database
        cursor.execute("CREATE DATABASE IF NOT EXISTS pkh_db")
        print("✅ Database 'pkh_db' berhasil dibuat/ditemukan")
        
        # Gunakan database
        cursor.execute("USE pkh_db")
        
        # Baca dan jalankan SQL file
        sql_file = "pkh_db.sql"
        if os.path.exists(sql_file):
            with open(sql_file, 'r', encoding='utf-8') as file:
                sql_commands = file.read()
                # Split commands by semicolon
                commands = sql_commands.split(';')
                for command in commands:
                    command = command.strip()
                    if command and not command.startswith('--'):
                        try:
                            cursor.execute(command)
                            conn.commit()
                        except Error as e:
                            if "already exists" not in str(e).lower():
                                print(f"⚠️  Warning: {e}")
            print("✅ SQL file berhasil dijalankan")
        else:
            print("⚠️  File pkh_db.sql tidak ditemukan")
        
        conn.close()
        return True
        
    except Error as e:
        print(f"❌ Error membuat database: {e}")
        return False

def main():
    print("🔧 Setup Database PKH")
    print("=" * 30)
    
    # Cek koneksi MySQL
    if not check_mysql_connection():
        print("\n💡 Solusi:")
        print("1. Pastikan MySQL server sudah berjalan")
        print("2. Periksa konfigurasi di database.py")
        print("3. Jika menggunakan XAMPP/Laragon, pastikan MySQL service aktif")
        return False
    
    # Buat database
    if not create_database():
        print("\n💡 Solusi:")
        print("1. Pastikan user MySQL memiliki hak akses untuk membuat database")
        print("2. Periksa file pkh_db.sql")
        return False
    
    print("\n✅ Setup database selesai!")
    print("Aplikasi siap dijalankan dengan: python app.py")
    return True

if __name__ == "__main__":
    main() 