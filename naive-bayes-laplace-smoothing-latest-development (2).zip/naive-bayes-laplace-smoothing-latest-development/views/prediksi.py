import gradio as gr
from lib import database
from lib.auth import get_user_role
import pandas as pd
import math
# =====================
# HALAMAN PREDIKSI PKH
# =====================
# Di sini semua data dari database + data input form akan dipakai untuk prediksi, tanpa split data latih/uji.
# Komentar dibuat supaya gampang paham alurnya, kayak penjelasan ke teman sendiri :)
def prediksi_view(user_state):
    # Ambil role user (kepala/pegawai/unauthorized)
    role = get_user_role(user_state)

    def prediksi_kelayakan(nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, status_input):
        # Cek role user

        current_role = get_user_role(user_state)
        is_kepala = current_role == "kepala"
        is_pegawai = current_role == "pegawai"
        is_unauthorized = current_role == "unauthorized"
        status_approval = "valid" if is_kepala else "pending"
        try:
            # Ambil seluruh data masyarakat (bukan data latih/uji, exclude prediksi)
            df = database.fetch_all_masyarakat()
            if len(df) < 5:
                return {"error": "❌ **Data training tidak cukup. Minimal 5 data diperlukan.**"}
            # --- Definisi fitur dan bobot ---
            fitur_list = [
                ('Pekerjaan Ayah', 'pekerjaan_ayah'),
                ('Jumlah Anak', 'jumlah_anak'),
                ('Ibu Hamil', 'ibu_hamil'),
                ('Disabilitas', 'disabilitas'),
                ('Lansia (>60th)', 'lansia'),
            ]
            bobot_fitur = {
                'pekerjaan_ayah': (1 + 1/2 + 1/3 + 1/4 + 1/5) / 5,
                'jumlah_anak': (0 + 1/2 + 1/3 + 1/4 + 1/5) / 5,
                'ibu_hamil': (0 + 0 + 1/3 + 1/4 + 1/5) / 5,
                'disabilitas': (0 + 0 + 0 + 1/4 + 1/5) / 5,
                'lansia': (0 + 0 + 0 + 0 + 1/5) / 5,
            }
            # --- Mapping kategori ---
            df_kriteria = pd.DataFrame([
                ["Pekerjaan Ayah", "Tidak Bekerja", "Rendah"],
                ["", "Buruh", "Rendah"],
                ["", "Mengurus Rumah Tangga", "Rendah"],
                ["", "Karyawan", "Sedang"],
                ["", "Pengusaha", "Tinggi"],
                ["", "PNS", "Sangat Tinggi"],
                ["Jumlah Anak", "0", "Rendah"],
                ["", "1", "Rendah"],
                ["", "2", "Sedang"],
                ["", "3", "Tinggi"],
                ["", "4 anak lebih", "Sangat Tinggi"],
                ["Ibu Hamil", "Ya", "Rendah"],
                ["", "Tidak", "Sedang"],
                ["Disabilitas", "Ya", "Rendah"],
                ["", "Tidak", "Sedang"],
                ["Lansia (>60th)", "Ya", "Rendah"],
                ["", "Tidak", "Sedang"],
            ], columns=["Kriteria", "Indikator", "Kategorial (Mampu)"])
            mapping_fitur = {}
            for fitur, _ in fitur_list:
                subdf = df_kriteria[df_kriteria['Kriteria'].replace('', None).ffill() == fitur]
                mapping_fitur[fitur] = dict(zip(subdf['Indikator'], subdf['Kategorial (Mampu)']))
            def kategori_jumlah_anak(val):
                try:
                    val_int = int(val)
                except:
                    return None
                if val_int == 0 or val_int == 1:
                    return "Rendah"
                elif val_int == 2:
                    return "Sedang"
                elif val_int == 3:
                    return "Tinggi"
                elif val_int >= 4:
                    return "Sangat Tinggi"
                return None
            # --- Hitung prior dari seluruh data masyarakat ---
            jml_dapat = (df['kategori'] == 'Dapat').sum()
            jml_tidak = (df['kategori'] == 'Tidak dapat').sum()
            total = jml_dapat + jml_tidak
            prob_dapat = jml_dapat / total if total else 0
            prob_tidak = jml_tidak / total if total else 0
            # --- Hitung likelihood per fitur dari seluruh data masyarakat ---
            prob_kategori = {}
            for fitur, kolom in fitur_list:
                indikator_to_kat = mapping_fitur[fitur]
                data_fitur = df.copy()
                # Konversi angka ke string untuk mapping kategori
                if fitur in ["Ibu Hamil", "Disabilitas", "Lansia (>60th)"]:
                    data_fitur[kolom] = data_fitur[kolom].apply(lambda x: "Ya" if str(x) == "2" else "Tidak")
                if fitur == "Jumlah Anak":
                    data_fitur['kategori_fitur'] = data_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_fitur['kategori_fitur'] = data_fitur[kolom].map(indikator_to_kat)
                kategori_unik = list(sorted(set(data_fitur['kategori_fitur'].dropna().unique())))
                prob_kategori[fitur] = {}
                for kat in kategori_unik:
                    x_dapat = ((data_fitur['kategori_fitur'] == kat) & (data_fitur['kategori'] == 'Dapat')).sum()
                    p_dapat = (x_dapat + 1) / (jml_dapat + 1*2)
                    x_tidak = ((data_fitur['kategori_fitur'] == kat) & (data_fitur['kategori'] == 'Tidak dapat')).sum()
                    p_tidak = (x_tidak + 1) / (jml_tidak + 1*2)
                    prob_kategori[fitur][kat] = {
                        'Dapat': p_dapat,
                        'Tidak dapat': p_tidak
                    }
            # --- Ambil input user dan mapping ke kategori ---
            input_kat = {}
            for fitur, kolom in fitur_list:
                if fitur == "Jumlah Anak":
                    input_kat[fitur] = kategori_jumlah_anak(jumlah_anak)
                else:
                    indikator_to_kat = mapping_fitur[fitur]
                    val = locals()[kolom]
                    input_kat[fitur] = indikator_to_kat.get(str(val))
            # --- Hitung probabilitas akhir ---
            p_dapat_x = prob_dapat
            p_tidak_x = prob_tidak
            komponen_p_dapat = [f"{prob_dapat:.3f}"]
            komponen_p_tidak = [f"{prob_tidak:.3f}"]
            for fitur, kolom in fitur_list:
                kat = input_kat[fitur]
                if kat is None:
                    continue
                if kat in prob_kategori[fitur]:
                    prob_dapat_fitur = prob_kategori[fitur][kat]['Dapat']
                    prob_tidak_fitur = prob_kategori[fitur][kat]['Tidak dapat']
                    bobot = bobot_fitur[kolom]
                    komponen_p_dapat.append(f"({prob_dapat_fitur:.3f}^{bobot:.3f})")
                    komponen_p_tidak.append(f"({prob_tidak_fitur:.3f}^{bobot:.3f})")
                    p_dapat_x *= prob_dapat_fitur ** bobot
                    p_tidak_x *= prob_tidak_fitur ** bobot
            p_dapat_x_rounded = math.ceil(p_dapat_x * 1000) / 1000
            p_tidak_x_rounded = math.ceil(p_tidak_x * 1000) / 1000
            status = "Dapat" if p_dapat_x_rounded > p_tidak_x_rounded else "Tidak dapat"
            waktu = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
            # Simpan ke tabel prediksi (bukan masyarakat)
            hasil_str = f"P(Dapat): {p_dapat_x_rounded:.3f}, P(Tidak Dapat): {p_tidak_x_rounded:.3f}, Status: {status}"
            def to_db_bool(val):
                if str(val).lower() in ["ya", "1", "true"]:
                    return 1
                return 0
            label_aktual = None
            try:
                df_masyarakat = database.fetch_all_masyarakat()
                match = df_masyarakat[(df_masyarakat['nama'] == nama) &
                                      (df_masyarakat['pekerjaan_ayah'] == pekerjaan_ayah) &
                                      (df_masyarakat['jumlah_anak'] == int(jumlah_anak)) &
                                      (df_masyarakat['ibu_hamil'] == to_db_bool(ibu_hamil)) &
                                      (df_masyarakat['disabilitas'] == to_db_bool(disabilitas)) &
                                      (df_masyarakat['lansia'] == to_db_bool(lansia))]
                if not match.empty:
                    label_aktual = match.iloc[0]['kategori']
            except Exception:
                label_aktual = None
            # Jika tetap None, ambil dari status_input
            if label_aktual is None:
                label_aktual = status_input
            db_data = {
                'nama': nama,
                'pekerjaan_ayah': pekerjaan_ayah,
                'jumlah_anak': jumlah_anak,
                'ibu_hamil': to_db_bool(ibu_hamil),
                'disabilitas': to_db_bool(disabilitas),
                'lansia': to_db_bool(lansia),
                'hasil': hasil_str,
                'status': status_approval,
                'label_aktual': label_aktual
            }
            inserted = database.insert_prediksi(db_data)
            if not inserted:
                return {"error": "❌ **Gagal menyimpan hasil prediksi ke database. Cek koneksi atau struktur tabel.**"}
            # Gabungkan data kelola + input prediksi
            input_row = {
                'id': df['id'].max() + 1 if 'id' in df.columns and not df.empty else 1,
                'nama': nama,
                'pekerjaan_ayah': pekerjaan_ayah,
                'jumlah_anak': jumlah_anak,
                'ibu_hamil': 2 if ibu_hamil == "Ya" else 1,
                'disabilitas': 2 if disabilitas == "Ya" else 1,
                'lansia': 2 if lansia == "Ya" else 1,
                'kategori': status_input  # gunakan input status aktual
            }
            df_pred = pd.concat([df, pd.DataFrame([input_row])], ignore_index=True)

            # Step 1: Inisialisasi data
            step_md = []
            step_md.append("""<div style='background:#DCEEFB;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>1. Inisialisasi data</div>""")
            step_md.append(f"Jumlah data (termasuk input prediksi): <b>{len(df_pred)}</b>")
            # Step 2: Penjelasan kriteria
            step_md.append("""<div style='background:#DCEEFB;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>2. Penjelasan Kriteria dan Kategoria</div>""")
            step_md.append(df_kriteria.to_html(index=False, border=1))
            # Step 3: Tabel data
            fitur_kolom = ['id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'kategori']
            
            # Konversi nilai angka menjadi "Tidak" dan "Ya" untuk tampilan
            df_pred_display = df_pred[fitur_kolom].copy()
            def convert_to_yes_no(val):
                if pd.isna(val) or val == '':
                    return ''
                try:
                    val_int = int(val)
                    return "Ya" if val_int == 2 else "Tidak"
                except:
                    return str(val)
            
            # Terapkan konversi untuk kolom ibu_hamil, disabilitas, dan lansia
            df_pred_display['ibu_hamil'] = df_pred_display['ibu_hamil'].apply(convert_to_yes_no)
            df_pred_display['disabilitas'] = df_pred_display['disabilitas'].apply(convert_to_yes_no)
            df_pred_display['lansia'] = df_pred_display['lansia'].apply(convert_to_yes_no)
            
            step_md.append("""<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>3. Data (Kelola + Input Prediksi)</div>""")
            step_md.append(df_pred_display.to_html(index=False, border=1))
            # Step 4: Probabilitas kelas
            step_md.append("""<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>4. Probabilitas Kelas</div>""")
            df_prob_kelas = pd.DataFrame([
                ["Dapat", f"{prob_dapat:.3f}"],
                ["Tidak Dapat", f"{prob_tidak:.3f}"]
            ], columns=["Kelas", "Probabilitas"])
            step_md.append(df_prob_kelas.to_html(index=False, border=1))
            # Step 5: Probabilitas fitur
            step_md.append("""<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>5. Probabilitas Fitur</div>""")
            for fitur, kolom in fitur_list:
                indikator_to_kat = mapping_fitur[fitur]
                data_fitur = df.copy()
                # Konversi angka ke string untuk mapping kategori
                if fitur in ["Ibu Hamil", "Disabilitas", "Lansia (>60th)"]:
                    data_fitur[kolom] = data_fitur[kolom].apply(lambda x: "Ya" if str(x) == "2" else "Tidak")
                if fitur == "Jumlah Anak":
                    data_fitur['kategori_fitur'] = data_fitur[kolom].apply(kategori_jumlah_anak)
                    kategori_mapping = ['Rendah', 'Sedang', 'Tinggi', 'Sangat Tinggi']
                else:
                    data_fitur['kategori_fitur'] = data_fitur[kolom].map(indikator_to_kat)
                    kategori_mapping = list(dict.fromkeys(indikator_to_kat.values()))
                rows = []
                for kat in kategori_mapping:
                    x_dapat = ((data_fitur['kategori_fitur'] == kat) & (data_fitur['kategori'] == 'Dapat')).sum()
                    n_dapat = (data_fitur['kategori'] == 'Dapat').sum()
                    p_dapat = (x_dapat + 1) / (n_dapat + 1*2) if n_dapat > 0 else 0
                    x_tidak = ((data_fitur['kategori_fitur'] == kat) & (data_fitur['kategori'] == 'Tidak dapat')).sum()
                    n_tidak = (data_fitur['kategori'] == 'Tidak dapat').sum()
                    p_tidak = (x_tidak + 1) / (n_tidak + 1*2) if n_tidak > 0 else 0
                    rows.append([kat, x_dapat, f"{p_dapat:.3f}", x_tidak, f"{p_tidak:.3f}"])
                df_prob_fitur = pd.DataFrame(rows, columns=[f"Kategori {fitur}", "Frekuensi Dapat", "P(Kategori|Dapat)", "Frekuensi Tidak Dapat", "P(Kategori|Tidak Dapat)"])
                step_md.append(f"<b>Probabilitas kategori pada fitur <span style='color:#007700'>{fitur}</span></b>")
                step_md.append(df_prob_fitur.to_html(index=False, border=1))
            # Step 6: Bobot fitur
            step_md.append("""<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>6. Bobot Fitur</div>""")
            df_bobot = pd.DataFrame([
                ["Pekerjaan Ayah", f"{bobot_fitur['pekerjaan_ayah']:.3f}"],
                ["Jumlah Anak", f"{bobot_fitur['jumlah_anak']:.3f}"],
                ["Ibu Hamil", f"{bobot_fitur['ibu_hamil']:.3f}"],
                ["Disabilitas", f"{bobot_fitur['disabilitas']:.3f}"],
                ["Lansia", f"{bobot_fitur['lansia']:.3f}"],
            ], columns=["Fitur", "Bobot"])
            step_md.append(df_bobot.to_html(index=False, border=1))
            # Step 7: Rekap Probabilitas Kategori per Fitur
            step_md.append("""<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>7. Rekap Probabilitas Kategori per Fitur</div>""")
            for fitur, kolom in fitur_list:
                indikator_to_kat = mapping_fitur[fitur]
                data_fitur = df.copy()
                # Konversi angka ke string untuk mapping kategori
                if fitur in ["Ibu Hamil", "Disabilitas", "Lansia (>60th)"]:
                    data_fitur[kolom] = data_fitur[kolom].apply(lambda x: "Ya" if str(x) == "2" else "Tidak")
                if fitur == "Jumlah Anak":
                    data_fitur['kategori_fitur'] = data_fitur[kolom].apply(kategori_jumlah_anak)
                    kategori_mapping = ['Rendah', 'Sedang', 'Tinggi', 'Sangat Tinggi']
                else:
                    data_fitur['kategori_fitur'] = data_fitur[kolom].map(indikator_to_kat)
                    kategori_mapping = list(dict.fromkeys(indikator_to_kat.values()))
                rows = []
                for kat in kategori_mapping:
                    x_dapat = ((data_fitur['kategori_fitur'] == kat) & (data_fitur['kategori'] == 'Dapat')).sum()
                    n_dapat = (data_fitur['kategori'] == 'Dapat').sum()
                    p_dapat = (x_dapat + 1) / (n_dapat + 1*2) if n_dapat > 0 else 0
                    x_tidak = ((data_fitur['kategori_fitur'] == kat) & (data_fitur['kategori'] == 'Tidak dapat')).sum()
                    n_tidak = (data_fitur['kategori'] == 'Tidak dapat').sum()
                    p_tidak = (x_tidak + 1) / (n_tidak + 1*2) if n_tidak > 0 else 0
                    rows.append([kat, x_dapat, f"{p_dapat:.3f}", x_tidak, f"{p_tidak:.3f}"])
                # Sort rows alphabetically by kategori (first column)
                rows_sorted = sorted(rows, key=lambda x: str(x[0]))
                df_prob_fitur = pd.DataFrame(rows_sorted, columns=[f"Kategori {fitur}", "Frekuensi Dapat", "P(Kategori|Dapat)", "Frekuensi Tidak Dapat", "P(Kategori|Tidak Dapat)"])
                step_md.append(f"<b>Probabilitas kategori pada fitur <span style='color:#007700'>{fitur}</span></b>")
                step_md.append(df_prob_fitur.to_html(index=False, border=1))
            # Step 8: Hasil Perhitungan Probabilitas Input
            # Tampilkan seluruh data hasil perhitungan probabilitas
            hasil_perhitungan = []
            for idx, row in df_pred.iterrows():
                no = idx + 1
                nama_row = row['nama']
                p_dapat_x = prob_dapat
                p_tidak_x = prob_tidak
                for fitur, kolom in fitur_list:
                    val = row[kolom]
                    if fitur in ["Ibu Hamil", "Disabilitas", "Lansia (>60th)"]:
                        val = "Ya" if str(val) == "2" else "Tidak"
                    if fitur == "Jumlah Anak":
                        kategori = kategori_jumlah_anak(row[kolom])
                    else:
                        indikator_to_kat = mapping_fitur[fitur]
                        kategori = indikator_to_kat.get(str(val))
                    if kategori is None:
                        continue
                    if fitur in prob_kategori and kategori in prob_kategori[fitur]:
                        prob_dapat_fitur = prob_kategori[fitur][kategori]['Dapat']
                        prob_tidak_fitur = prob_kategori[fitur][kategori]['Tidak dapat']
                        bobot = bobot_fitur[kolom]
                        p_dapat_x *= prob_dapat_fitur ** bobot
                        p_tidak_x *= prob_tidak_fitur ** bobot
                p_dapat_x_rounded = math.ceil(p_dapat_x * 1000) / 1000
                p_tidak_x_rounded = math.ceil(p_tidak_x * 1000) / 1000
                status_row = "Dapat" if p_dapat_x_rounded > p_tidak_x_rounded else "Tidak dapat"
                hasil_perhitungan.append([
                    no,
                    nama_row,
                    f"{p_dapat_x_rounded:.3f}",
                    f"{p_tidak_x_rounded:.3f}",
                    status_row
                ])
            df_hasil = pd.DataFrame(
                hasil_perhitungan,
                columns=[
                    "No", "Nama",
                    "P (Dapat | X)",
                    "P (Tidak dapat | X)",
                    "Status"
                ]
            )
            step_md.append(df_hasil.to_html(index=False, border=1))
            # Di bawah tabel, tampilkan probabilitas dan status hasil prediksi untuk data input
            step_md.append(f"<br/><b>Probabilitas Data Input:</b><br/>P(Dapat|X): {p_dapat_x_rounded:.3f} | P(Tidak Dapat|X): {p_tidak_x_rounded:.3f} | Status: {status}")
            breakdown_html = "\n".join(step_md)
            if is_kepala:
                return {
                    "nama": nama,
                    "pekerjaan_ayah": pekerjaan_ayah,
                    "jumlah_anak": jumlah_anak,
                    "ibu_hamil": ibu_hamil,
                    "disabilitas": disabilitas,
                    "lansia": lansia,
                    "prob_dapat": f"{p_dapat_x_rounded:.3f}",
                    "prob_tidak": f"{p_tidak_x_rounded:.3f}",
                    "status": status,
                    "status_approval": status_approval,
                    "waktu": waktu,
                    "breakdown": breakdown_html
                }
            else:
                return {"alert_only": True}
        except Exception as e:
            return {"error": f"❌ **Error:** {str(e)}"}

    with gr.Column():
        gr.Markdown("""
        # 🎯 Prediksi Kelayakan PKH
        > **Catatan:**
        > Seluruh data yang ada di menu **Kelola Data** digunakan sebagai data training untuk menghitung probabilitas prediksi. Hasil prediksi hanya untuk data yang Anda input di bawah ini, dan hasilnya akan disimpan ke database.
        """)
        refresh_data_btn = gr.Button("🔄 Refresh Data", size="sm")
        gr.Markdown("Masukkan data untuk memprediksi kelayakan bantuan PKH")
        with gr.Row():
            with gr.Column(scale=1):
                nama = gr.Textbox(label="Nama", value="", placeholder="Nama Lengkap")
                pekerjaan_ayah = gr.Dropdown(
                    ['Tidak Bekerja', 'Buruh', 'Mengurus Rumah Tangga', 'Karyawan', 'Pengusaha', 'PNS'],
                    label="Pekerjaan Ayah", value='Tidak Bekerja'
                )
                jumlah_anak = gr.Number(label="Jumlah Anak", minimum=0, value=0, step=1)
                ibu_hamil = gr.Dropdown(
                    choices=["Tidak", "Ya"], label="Ibu Hamil", value="Tidak"
                )
                disabilitas = gr.Dropdown(
                    choices=["Tidak", "Ya"], label="Disabilitas", value="Tidak"
                )
                lansia = gr.Dropdown(
                    choices=["Tidak", "Ya"], label="Lansia", value="Tidak"
                )
                status_input = gr.Dropdown(
                    choices=["Dapat", "Tidak Dapat"], label="Status (Aktual)", value="Dapat"
                )
                prediksi_btn = gr.Button("🎯 Prediksi", variant="primary", size="lg")
            with gr.Column(scale=1):
                hasil_prediksi = gr.Markdown("## Hasil Prediksi")
                prob_dapat = gr.Textbox(label="Probabilitas Dapat", interactive=False)
                prob_tidak = gr.Textbox(label="Probabilitas Tidak Dapat", interactive=False)
                status_prediksi = gr.Textbox(label="Status", interactive=False)
                status_approval = gr.Textbox(label="Status Approval", interactive=False)
                waktu_prediksi = gr.Textbox(label="Waktu Prediksi", interactive=False)
        # Event handler
        breakdown_html = gr.HTML(visible=(role=="kepala"))
        def handle_prediksi(nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, status_input):
            result = prediksi_kelayakan(nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, status_input)
            if "error" in result:
                return result["error"], "", "", "", "", "", ""
            if "alert_only" in result:
                return "✅ Data berhasil disimpan, menunggu approval kepala.", "", "", "", "", "", ""
            return (
                f"### Nama: {result['nama']}\nPekerjaan Ayah: {result['pekerjaan_ayah']}\nJumlah Anak: {result['jumlah_anak']}\nIbu Hamil: {result['ibu_hamil']}\nDisabilitas: {result['disabilitas']}\nLansia: {result['lansia']}",
                result["prob_dapat"],
                result["prob_tidak"],
                result["status"],
                result["status_approval"],
                result["waktu"],
                result.get("breakdown", "")
            )
        prediksi_btn.click(
            fn=handle_prediksi,
            inputs=[nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, status_input],
            outputs=[hasil_prediksi, prob_dapat, prob_tidak, status_prediksi, status_approval, waktu_prediksi, breakdown_html]
        )

        # Tabel approval untuk kepala - hanya tampilkan jika role = kepala
        approval_container = gr.Group(visible=False)
        with approval_container:
            gr.Markdown("## Tabel Prediksi Menunggu Validasi")
            def fetch_pending_prediksi():
                try:
                    df = database.fetch_pending_prediksi()
                    if df.empty:
                        return pd.DataFrame(columns=['id', 'nama', 'pekerjaan', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'hasil', 'status'])
                    # Hanya rename kolom untuk tampilan header tabel
                    df = df.rename(columns={'pekerjaan_ayah': 'pekerjaan'})
                    return df
                except Exception:
                    return pd.DataFrame(columns=['id', 'nama', 'pekerjaan', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'hasil', 'status'])

            pending_table = gr.DataFrame(
                fetch_pending_prediksi(),
                label="Prediksi Menunggu Validasi",
                interactive=False,
                wrap=True
            )
            # Tombol approve (validasi)
            approve_id = gr.Number(label="ID Prediksi untuk Approve", value=0, step=1)
            approve_btn = gr.Button("✅ Approve Prediksi", variant="primary", size="sm")
            def handle_approve_prediksi(prediksi_id):
                try:
                    if int(prediksi_id) > 0:
                        database.update_prediksi_status(int(prediksi_id), "valid")
                    return fetch_pending_prediksi()
                except Exception:
                    return fetch_pending_prediksi()
            approve_btn.click(fn=handle_approve_prediksi, inputs=[approve_id], outputs=[pending_table])

        # Function untuk update visibility approval table dan refresh data
        def update_approval_visibility_and_refresh():
            current_role = get_user_role(user_state)
            return gr.update(visible=(current_role == "kepala")), fetch_pending_prediksi()
        
        # Bind refresh data button
        refresh_data_btn.click(fn=update_approval_visibility_and_refresh, outputs=[approval_container, pending_table]) 