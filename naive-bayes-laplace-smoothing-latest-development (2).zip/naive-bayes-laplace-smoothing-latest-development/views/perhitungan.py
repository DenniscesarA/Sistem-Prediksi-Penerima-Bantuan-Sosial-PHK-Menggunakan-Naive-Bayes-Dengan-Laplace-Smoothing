import gradio as gr
import pandas as pd
import math

def perhitungan_html(fetch_table_func):
    df = fetch_table_func()
    jumlah_data = len(df) if isinstance(df, pd.DataFrame) else 0
    html = []
    html.append("<div style='background:#DCEEFB;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>1. Inisialisasi data</div>")
    if jumlah_data > 0:
        n_latih = int(round(jumlah_data * 0.7))
        n_uji = jumlah_data - n_latih
        df_summary = pd.DataFrame([
            ["jumlah", jumlah_data, "data"],
            ["70% nya", n_latih, "data latih"],
            ["30% nya", n_uji, "data uji"]
        ], columns=["", "Jumlah", "Keterangan"])
        html.append(df_summary.to_html(index=False, border=1))
        html.append(f"Jumlah data yang digunakan: <b>{jumlah_data}</b>")
    else:
        html.append("<b>Tidak ada data.</b>")
    html.append("<div style='background:#DCEEFB;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>2. Penjelasan Kriteria dan Kategoria</div>")
    df_kriteria = pd.DataFrame([
        ["Pekerjaan Ayah", "Tidak Bekerja", "Rendah"],
        ["", "Buruh", "Rendah"],
        ["", "Mengurus Rumah Tangga", "Rendah"],
        ["", "Karyawan", "Sedang"],
        ["", "Pengusaha", "Tinggi"],
        ["", "PNS", "Sangat Tinggi"],
        ["Jumlah Anak", "0", "Rendah"],
        ["", "1", "Rendah"],
        ["", "2", "Sedang"],
        ["", "3", "Tinggi"],
        ["", "4 anak lebih", "Sangat Tinggi"],
        ["Ibu Hamil", "Ya", "Rendah"],
        ["", "Tidak", "Sedang"],
        ["Disabilitas", "Ya", "Rendah"],
        ["", "Tidak", "Sedang"],
        ["Lansia (>60th)", "Ya", "Rendah"],
        ["", "Tidak", "Sedang"],
    ], columns=["Kriteria", "Indikator", "Kategorial (Mampu)"])
    html.append(df_kriteria.to_html(index=False, border=1))
    if jumlah_data > 0 and 'id' in df.columns and 'nama' in df.columns and 'kategori' in df.columns:
        df_sorted = df.sort_values('id')
        n_latih = int(round(jumlah_data * 0.7))
        n_uji = jumlah_data - n_latih
        fitur_kolom = ['id', 'nama',  'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia','kategori',]
        data_latih = df_sorted.iloc[:n_latih][fitur_kolom].copy()
        data_uji = df_sorted.iloc[n_latih:][fitur_kolom].copy()
        # Section 3: Pembagian Data Latih dan Data Uji
        html.append("<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>3. Pembagian Data Latih dan Data Uji</div>")
        fitur_list = [
            ('Pekerjaan Ayah', 'pekerjaan_ayah'),
            ('Jumlah Anak', 'jumlah_anak'),
            ('Ibu Hamil', 'ibu_hamil'),
            ('Disabilitas', 'disabilitas'),
            ('Lansia (>60th)', 'lansia'),
        ]
        def kategori_jumlah_anak(val):
            try:
                val_int = int(val)
            except:
                return None
            if val_int == 0 or val_int == 1:
                return "Rendah"
            elif val_int == 2:
                return "Sedang"
            elif val_int == 3:
                return "Tinggi"
            elif val_int >= 4:
                return "Sangat Tinggi"
            return None
        mapping_fitur = {}
        for fitur, _ in fitur_list:
            subdf = df_kriteria[df_kriteria['Kriteria'].replace('', None).ffill() == fitur]
            mapping_fitur[fitur] = dict(zip(subdf['Indikator'], subdf['Kategorial (Mampu)']))
        for idx, (fitur, kolom) in enumerate(fitur_list, 1):
            kat_col = f'kategorial{idx}'
            if kolom in data_latih.columns:
                if fitur == "Jumlah Anak":
                    data_latih[kat_col] = data_latih[kolom].apply(kategori_jumlah_anak)
                    data_uji[kat_col] = data_uji[kolom].apply(kategori_jumlah_anak)
                else:
                    indikator_to_kat = mapping_fitur[fitur]
                    data_latih[kat_col] = data_latih[kolom].map(indikator_to_kat)
                    data_uji[kat_col] = data_uji[kolom].map(indikator_to_kat)
        ordered_cols = [
            'id', 'nama',
            'pekerjaan_ayah', 'kategorial1',
            'jumlah_anak', 'kategorial2',
            'ibu_hamil', 'kategorial3',
            'lansia', 'kategorial4',
            'disabilitas', 'kategorial5',
            'kategori'
        ]
        ordered_cols = [col for col in ordered_cols if col in data_latih.columns]
        simple_header = []
        mapping_header = {
            'id': 'id',
            'nama': 'nama',
            'pekerjaan_ayah': 'pekerjaan_ayah',
            'kategorial1': 'K1',
            'jumlah_anak': 'jumlah_anak',
            'kategorial2': 'K2',
            'ibu_hamil': 'ibu_hamil',
            'kategorial3': 'K3',
            'lansia': 'lansia',
            'kategorial4': 'K4',
            'disabilitas': 'disabilitas',
            'kategorial5': 'K5',
            'kategori': 'Kategori'
        }
        for col in ordered_cols:
            simple_header.append(mapping_header.get(col, col))
        data_latih_simple = data_latih[ordered_cols].copy()
        data_latih_simple.columns = simple_header
        data_uji_simple = data_uji[ordered_cols].copy()
        data_uji_simple.columns = simple_header
        html.append(data_latih_simple.to_html(index=False, border=1))
        jml_latih = len(data_latih)
        jml_latih_dapat = (data_latih['kategori'] == 'Dapat').sum()
        jml_latih_tidak = (data_latih['kategori'] == 'Tidak dapat').sum()
        persen_latih_dapat = (jml_latih_dapat / jml_latih * 100) if jml_latih else 0
        persen_latih_tidak = (jml_latih_tidak / jml_latih * 100) if jml_latih else 0
        html.append(f"Jumlah Data Latih: <b>{jml_latih}</b> <br>Jumlah Data Latih Dapat: <b>{jml_latih_dapat}</b> ({persen_latih_dapat:.1f}%) <br>Jumlah Data Latih Tidak Dapat: <b>{jml_latih_tidak}</b> ({persen_latih_tidak:.1f}%)")
        # Section 4: Probabilitas kelas
        html.append("<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>4. Perhitungan nilai probabilitas masing-masing kelas</div>")
        prob_latih_dapat = (jml_latih_dapat / jml_latih) if jml_latih else 0
        prob_latih_tidak = (jml_latih_tidak / jml_latih) if jml_latih else 0
        
        # Tambahkan probabilitas data uji untuk konsistensi dengan Excel
        jml_uji = len(data_uji)
        jml_uji_dapat = (data_uji['kategori'] == 'Dapat').sum()
        jml_uji_tidak = (data_uji['kategori'] == 'Tidak dapat').sum()
        prob_uji_dapat = (jml_uji_dapat / jml_uji) if jml_uji else 0
        prob_uji_tidak = (jml_uji_tidak / jml_uji) if jml_uji else 0
        
        df_prob_latih = pd.DataFrame([
            [
                "Nilai probabilitas kelas Dapat pada data Latih",
                f"{prob_latih_dapat:.2f}".replace('.', ','),
                f"(jumlah data latih dapat / jumlah data latih) = {jml_latih_dapat}/{jml_latih}"
            ],
            [
                "Nilai probabilitas kelas Tidak Dapat pada data Latih",
                f"{prob_latih_tidak:.2f}".replace('.', ','),
                f"(jumlah data latih tidak / jumlah data latih) = {jml_latih_tidak}/{jml_latih}"
            ],
            [
                "Nilai probabilitas kelas Dapat pada data Uji",
                f"{prob_uji_dapat:.2f}".replace('.', ','),
                f"(jumlah data uji dapat / jumlah data uji) = {jml_uji_dapat}/{jml_uji}"
            ],
            [
                "Nilai probabilitas kelas Tidak Dapat pada data Uji",
                f"{prob_uji_tidak:.2f}".replace('.', ','),
                f"(jumlah data uji tidak / jumlah data uji) = {jml_uji_tidak}/{jml_uji}"
            ]
        ], columns=["", "Probabilitas", "Contoh Perhitungan"])
        html.append(df_prob_latih.to_html(index=False, border=1))
        # Section 5: Probabilitas fitur
        html.append("<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>5. Perhitungan nilai probabilitas masing-masing fitur pada data latih</div>")
        
        if jumlah_data > 0 and 'id' in df.columns and 'nama' in df.columns and 'kategori' in df.columns:
            # Tambahkan fungsi mapping khusus untuk Jumlah Anak
            def kategori_jumlah_anak(val):
                try:
                    val_int = int(val)
                except:
                    return None
                if val_int == 0 or val_int == 1:
                    return "Rendah"
                elif val_int == 2:
                    return "Sedang"
                elif val_int == 3:
                    return "Tinggi"
                elif val_int >= 4:
                    return "Sangat Tinggi"
                return None

            # Buat mapping fitur -> indikator -> kategori
            mapping_fitur = {}
            for fitur, _ in fitur_list:
                subdf = df_kriteria[df_kriteria['Kriteria'].replace('', None).ffill() == fitur]
                mapping_fitur[fitur] = dict(zip(subdf['Indikator'], subdf['Kategorial (Mampu)']))
            
            # Data latih sudah ada: data_latih
            jml_latih_dapat = (data_latih['kategori'] == 'Dapat').sum()
            jml_latih_tidak = (data_latih['kategori'] == 'Tidak dapat').sum()
            
            for fitur, kolom in fitur_list:
                if kolom not in data_latih.columns:
                    continue
                # Ambil mapping indikator->kategori
                indikator_to_kat = mapping_fitur[fitur]
                # Dapatkan semua kategori unik pada fitur tsb
                if fitur == "Pekerjaan Ayah":
                    kategori_unik = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                elif fitur == "Jumlah Anak":
                    kategori_unik = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                else:
                    kategori_unik = list(sorted(set(indikator_to_kat.values())))
                # Buat kolom kategori baru pada data_latih
                data_latih_fitur = data_latih.copy()
                if fitur == "Jumlah Anak":
                    data_latih_fitur['kategori_fitur'] = data_latih_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_latih_fitur['kategori_fitur'] = data_latih_fitur[kolom].map(indikator_to_kat)
                # Siapkan tabel hasil
                rows = []
                for kat in kategori_unik:
                    # Dapat
                    x_dapat = ((data_latih_fitur['kategori_fitur'] == kat) & (data_latih_fitur['kategori'] == 'Dapat')).sum()
                    n_dapat = (data_latih_fitur['kategori'] == 'Dapat').sum()
                    k = len(kategori_unik)
                    p_dapat = (x_dapat + 1) / (n_dapat + 1*(2)) if n_dapat > 0 else 0
                    # Tidak Dapat
                    x_tidak = ((data_latih_fitur['kategori_fitur'] == kat) & (data_latih_fitur['kategori'] == 'Tidak dapat')).sum()
                    n_tidak = (data_latih_fitur['kategori'] == 'Tidak dapat').sum()
                    p_tidak = (x_tidak + 1) / (n_tidak + 1*(2)) if n_tidak > 0 else 0 
                    rows.append([kat, x_dapat, f" {p_dapat:.2f}".replace('.', ','), x_tidak, f"{p_tidak:.2f}".replace('.', ',')])
                df_prob_fitur = pd.DataFrame(rows, columns=[f"Kategori {fitur}", "Frekuensi Dapat", "P(Kategori | Dapat)", "Frekuensi Tidak Dapat", "P(Kategori | Tidak dapat)"])
                html.append(f"<p><strong>Probabilitas kategori pada fitur <span style='color:#007700'>{fitur}</span></strong></p>")
                html.append(df_prob_fitur.to_html(index=False, border=1))

            # Section 6: Perhitungan Bobot Fitur
            html.append("<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>6. Perhitungan Bobot Fitur</div>")
            w1_pekerjaan = (1 + 1/2 + 1/3 + 1/4 + 1/5) / 5
            w2_anak = (0 + 1/2 + 1/3 + 1/4 + 1/5) / 5
            w3_hamil = (0 + 0 + 1/3 + 1/4 + 1/5) / 5
            w4_disabilitas = (0 + 0 + 0 + 1/4 + 1/5) / 5
            w5_lansia = (0 + 0 + 0 + 0 + 1/5) / 5
            total_bobot = w1_pekerjaan + w2_anak + w3_hamil + w4_disabilitas + w5_lansia
            df_bobot = pd.DataFrame([
                ["W1", "Pekerjaan Ayah", "(1+1/2+1/3+1/4+1/5)/5", f"{w1_pekerjaan:.4f}"],
                ["W2", "Jumlah Anak", "(0+1/2+1/3+1/4+1/5)/5", f"{w2_anak:.4f}"],
                ["W3", "Ibu Hamil", "(0+0+1/3+1/4+1/5)/5", f"{w3_hamil:.4f}"],
                ["W4", "Disabilitas", "(0+0+0+1/4+1/5)/5", f"{w4_disabilitas:.4f}"],
                ["W5", "Lansia", "(0+0+0+0+1/5)/5", f"{w5_lansia:.4f}"],
                ["Jumlah", "", "", f"{total_bobot:.4f}"]
            ], columns=["Bobot", "Fitur", "Rumus", "Nilai"])
            html.append(df_bobot.to_html(index=False, border=1))

            # Section 7: Rekap Probabilitas Kategori per Fitur pada Data Latih
            html.append("<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>7. Rekap Probabilitas Kategori per Fitur pada Data Latih</div>")
            
            # Buat tabel rekap probabilitas
            kategori_headers = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
            
            # Buat HTML tabel dengan styling
            html.append("<div style='margin: 20px 0;'>")
            html.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
            
            # Header utama
            html.append("<tr style='background-color: #f0f0f0;'>")
            html.append("<th rowspan='2' style='padding: 8px; text-align: center;'>Rekap Probabil</th>")
            html.append("<th colspan='4' style='padding: 8px; text-align: center; background-color: #90EE90;'>Dapat</th>")
            html.append("<th colspan='4' style='padding: 8px; text-align: center; background-color: #FFB6C1;'>Tidak Dapat</th>")
            html.append("</tr>")
            
            # Sub-header
            html.append("<tr style='background-color: #f0f0f0;'>")
            for kat in kategori_headers:
                html.append(f"<th style='padding: 8px; text-align: center; background-color: #90EE90;'>{kat}</th>")
            for kat in kategori_headers:
                html.append(f"<th style='padding: 8px; text-align: center; background-color: #FFB6C1;'>{kat}</th>")
            html.append("</tr>")
            
            # Data rows
            for fitur, kolom in fitur_list:
                if kolom not in data_latih.columns:
                    continue
                    
                indikator_to_kat = mapping_fitur[fitur]
                data_latih_fitur = data_latih.copy()
                if fitur == "Jumlah Anak":
                    data_latih_fitur['kategori_fitur'] = data_latih_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_latih_fitur['kategori_fitur'] = data_latih_fitur[kolom].map(indikator_to_kat)
                
                # Dapatkan kategori unik yang ada
                kategori_unik = list(sorted(set(data_latih_fitur['kategori_fitur'].dropna().unique())))
                
                # Untuk Pekerjaan Ayah dan Jumlah Anak, pastikan semua kategori muncul dengan urutan yang benar
                if fitur == "Pekerjaan Ayah":
                    semua_kategori = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                    kategori_unik = [kat for kat in semua_kategori if kat in kategori_unik or kat in indikator_to_kat.values()]
                elif fitur == "Jumlah Anak":
                    semua_kategori = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                    kategori_unik = [kat for kat in semua_kategori if kat in kategori_unik or kat in indikator_to_kat.values()]
                else:
                    # Untuk fitur lain, gunakan urutan default
                    kategori_unik = list(sorted(set(data_latih_fitur['kategori_fitur'].dropna().unique())))
                
                html.append("<tr>")
                html.append(f"<td style='padding: 8px; font-weight: bold;'>{fitur}</td>")
                
                # Kolom Dapat (hijau)
                for kat in kategori_headers:
                    if kat in kategori_unik:
                        x_dapat = ((data_latih_fitur['kategori_fitur'] == kat) & (data_latih_fitur['kategori'] == 'Dapat')).sum()
                        n_dapat = (data_latih_fitur['kategori'] == 'Dapat').sum()
                        p_dapat = (x_dapat + 1) / (n_dapat + 1*(2)) if n_dapat > 0 else 0
                        value = f"{p_dapat:.2f}".replace('.', ',')
                    else:
                        value = ""
                    html.append(f"<td style='padding: 8px; text-align: center; background-color: #90EE90;'>{value}</td>")
                
                # Kolom Tidak Dapat (oranye)
                for kat in kategori_headers:
                    if kat in kategori_unik:
                        x_tidak = ((data_latih_fitur['kategori_fitur'] == kat) & (data_latih_fitur['kategori'] == 'Tidak dapat')).sum()
                        n_tidak = (data_latih_fitur['kategori'] == 'Tidak dapat').sum()
                        p_tidak = (x_tidak + 1) / (n_tidak + 1*(2)) if n_tidak > 0 else 0
                        value = f"{p_tidak:.2f}".replace('.', ',')
                    else:
                        value = ""
                    html.append(f"<td style='padding: 8px; text-align: center; background-color: #FFB6C1;'>{value}</td>")
                
                html.append("</tr>")
            
            html.append("</table>")
            html.append("</div>")

            # Section 8: Hasil Perhitungan data latih
            html.append("<div style='background:#DEF7EC;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>8. Hasil Perhitungan data latih</div>")
            
            w1_pekerjaan = (1 + 1/2 + 1/3 + 1/4 + 1/5) / 5
            w2_anak = (0 + 1/2 + 1/3 + 1/4 + 1/5) / 5
            w3_hamil = (0 + 0 + 1/3 + 1/4 + 1/5) / 5
            w4_disabilitas = (0 + 0 + 0 + 1/4 + 1/5) / 5
            w5_lansia = (0 + 0 + 0 + 0 + 1/5) / 5
            
            bobot_fitur = {
                'pekerjaan_ayah': w1_pekerjaan,
                'jumlah_anak': w2_anak,
                'ibu_hamil': w3_hamil,
                'disabilitas': w4_disabilitas,
                'lansia': w5_lansia
            }
            
            prob_kategori = {}
            for fitur, kolom in fitur_list:
                if kolom not in data_latih.columns:
                    continue
                indikator_to_kat = mapping_fitur[fitur]
                data_latih_fitur = data_latih.copy()
                if fitur == "Jumlah Anak":
                    data_latih_fitur['kategori_fitur'] = data_latih_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_latih_fitur['kategori_fitur'] = data_latih_fitur[kolom].map(indikator_to_kat)
                prob_kategori[fitur] = {}
                kategori_unik = list(sorted(set(data_latih_fitur['kategori_fitur'].dropna().unique())))
                for kat in kategori_unik:
                    # Gunakan data latih untuk konsistensi dengan Excel
                    x_dapat = ((data_latih_fitur['kategori_fitur'] == kat) & (data_latih_fitur['kategori'] == 'Dapat')).sum()
                    n_dapat = (data_latih_fitur['kategori'] == 'Dapat').sum()
                    p_dapat = (x_dapat + 1) / (n_dapat + 1*(2)) if n_dapat > 0 else 0
                    x_tidak = ((data_latih_fitur['kategori_fitur'] == kat) & (data_latih_fitur['kategori'] == 'Tidak dapat')).sum()
                    n_tidak = (data_latih_fitur['kategori'] == 'Tidak dapat').sum()
                    p_tidak = (x_tidak + 1) / (n_tidak + 1*(2)) if n_tidak > 0 else 0
                    prob_kategori[fitur][kat] = {
                        'Dapat': p_dapat,
                        'Tidak dapat': p_tidak
                    }
            
            hasil_perhitungan = []
            
            for idx, (_, row) in enumerate(data_latih.iterrows(), 1):
                no = idx
                nama = row['nama']
                # Gunakan probabilitas dari data latih untuk konsistensi dengan Excel
                p_dapat_x = prob_latih_dapat   
                p_tidak_x = prob_latih_tidak  
                for fitur, kolom in fitur_list:
                    if kolom not in row:
                        continue
                    if fitur == "Jumlah Anak":
                        kategori = kategori_jumlah_anak(row[kolom])
                    else:
                        nilai_fitur = str(row[kolom])
                        indikator_to_kat = mapping_fitur[fitur]
                        kategori = indikator_to_kat.get(nilai_fitur)
                    if kategori is None:
                        continue
                    if fitur in prob_kategori and kategori in prob_kategori[fitur]:
                        prob_dapat = prob_kategori[fitur][kategori]['Dapat']
                        prob_tidak = prob_kategori[fitur][kategori]['Tidak dapat']
                        bobot = bobot_fitur[kolom]
                        hasil_pangkat_dapat = prob_dapat ** bobot
                        hasil_pangkat_tidak = prob_tidak ** bobot
                        p_dapat_x *= hasil_pangkat_dapat
                        p_tidak_x *= hasil_pangkat_tidak
                
                # Bulatkan ke atas 3 angka di belakang koma
                p_dapat_x_rounded = math.ceil(p_dapat_x * 1000) / 1000
                p_tidak_x_rounded = math.ceil(p_tidak_x * 1000) / 1000
                
                # Status prediksi
                if p_tidak_x_rounded < p_dapat_x_rounded:
                    status_prediksi = "Dapat"
                else:
                    status_prediksi = "Tidak dapat"
                
                # Status aktual dari data
                status_aktual = row['kategori']
                
                hasil_perhitungan.append([
                    no,
                    nama,
                    status_aktual,
                    f"{p_dapat_x_rounded:.3f}".replace('.', ','),
                    f"{p_tidak_x_rounded:.3f}".replace('.', ','),
                    status_prediksi
                ])
            
            # Buat DataFrame hasil
            df_hasil = pd.DataFrame(
                hasil_perhitungan,
                columns=[
                    "No", "Nama", "Status Aktual",
                    "P (Dapat | X)", "P (Tidak dapat | X)",
                    "Status Prediksi"
                ]
            )
            
            html.append(df_hasil.to_html(index=False, border=1))

            # Section 9: Pembagian Data Uji
            html.append("<div style='background:#FDF6B2;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>9. Pembagian Data Uji</div>")
            html.append(data_uji_simple.to_html(index=False, border=1))
            jml_uji = len(data_uji)
            jml_uji_dapat = (data_uji['kategori'] == 'Dapat').sum()
            jml_uji_tidak = (data_uji['kategori'] == 'Tidak dapat').sum()
            persen_uji_dapat = (jml_uji_dapat / jml_uji * 100) if jml_uji else 0
            persen_uji_tidak = (jml_uji_tidak / jml_uji * 100) if jml_uji else 0
            html.append(f"Jumlah Data Uji: <b>{jml_uji}</b> <br>Jumlah Data Uji Dapat: <b>{jml_uji_dapat}</b> ({persen_uji_dapat:.1f}%) <br>Jumlah Data Uji Tidak Dapat: <b>{jml_uji_tidak}</b> ({persen_uji_tidak:.1f}%)")

            # Section 10: Probabilitas kelas pada data uji
            html.append("<div style='background:#FDF6B2;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>10. Perhitungan nilai probabilitas masing-masing kelas pada data uji</div>")
            prob_uji_dapat = (jml_uji_dapat / jml_uji) if jml_uji else 0
            prob_uji_tidak = (jml_uji_tidak / jml_uji) if jml_uji else 0
            df_prob_uji = pd.DataFrame([
                [
                    "Nilai probabilitas kelas Dapat pada data Uji",
                    f"{prob_uji_dapat:.2f}".replace('.', ','),
                    f"(jumlah data uji dapat / jumlah data uji) = {jml_uji_dapat}/{jml_uji}"
                ],
                [
                    "Nilai probabilitas kelas Tidak Dapat pada data Uji",
                    f"{prob_uji_tidak:.2f}".replace('.', ','),
                    f"(jumlah data uji tidak / jumlah data uji) = {jml_uji_tidak}/{jml_uji}"
                ]
            ], columns=["", "Probabilitas", "Contoh Perhitungan"])
            html.append(df_prob_uji.to_html(index=False, border=1))

            # Section 11: Probabilitas fitur pada data uji
            html.append("<div style='background:#FDF6B2;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>11. Perhitungan nilai probabilitas masing-masing fitur pada data uji</div>")
            for fitur, kolom in fitur_list:
                if kolom not in df.columns:
                    continue
                indikator_to_kat = mapping_fitur[fitur]
                
                # Define custom order for categories
                custom_order = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                kategori_unik = [kat for kat in custom_order if kat in set(indikator_to_kat.values())]
                
                data_uji_fitur = data_uji.copy()
                if fitur == "Jumlah Anak":
                    data_uji_fitur['kategori_fitur'] = data_uji_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_uji_fitur['kategori_fitur'] = data_uji_fitur[kolom].map(indikator_to_kat)
                rows = []
                for kat in kategori_unik:
                    x_dapat = ((data_uji_fitur['kategori_fitur'] == kat) & (data_uji_fitur['kategori'] == 'Dapat')).sum()
                    n_dapat = (data_uji_fitur['kategori'] == 'Dapat').sum()
                    p_dapat = (x_dapat + 1) / (jml_uji_dapat + 1*(2))
                    x_tidak = ((data_uji_fitur['kategori_fitur'] == kat) & (data_uji_fitur['kategori'] == 'Tidak dapat')).sum()
                    n_tidak = (data_uji_fitur['kategori'] == 'Tidak dapat').sum()
                    p_tidak = (x_tidak + 1) / (jml_uji_tidak + 1*(2))
                    rows.append([kat, x_dapat, f" {p_dapat:.2f}".replace('.', ','), x_tidak, f"{p_tidak:.2f}".replace('.', ',')])
                df_prob_fitur_uji = pd.DataFrame(rows, columns=[f"Kategori {fitur}", "Frekuensi Dapat", "P(Kategori | Dapat)", "Frekuensi Tidak Dapat", "P(Kategori | Tidak dapat)"])
                html.append(df_prob_fitur_uji.to_html(index=False, border=1))

            # Section 12: Bobot Fitur Data Uji
            html.append("<div style='background:#FDF6B2;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>12. Perhitungan Bobot Fitur (Data Uji)</div>")
            html.append(df_bobot.to_html(index=False, border=1))

            # Section 13: Rekap Probabilitas Kategori per Fitur pada Data Uji
            html.append("<div style='background:#FDF6B2;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>13. Rekap Probabilitas Kategori per Fitur pada Data Uji</div>")
            
            # Buat tabel rekap probabilitas
            kategori_headers = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
            
            # Buat HTML tabel dengan styling
            html.append("<div style='margin: 20px 0;'>")
            html.append("<table border='1' style='border-collapse: collapse; width: 100%;'>")
            
            # Header utama
            html.append("<tr style='background-color: #f0f0f0;'>")
            html.append("<th rowspan='2' style='padding: 8px; text-align: center;'>Rekap Probabil</th>")
            html.append("<th colspan='4' style='padding: 8px; text-align: center; background-color: #90EE90;'>Dapat</th>")
            html.append("<th colspan='4' style='padding: 8px; text-align: center; background-color: #FFB6C1;'>Tidak Dapat</th>")
            html.append("</tr>")
            
            # Sub-header
            html.append("<tr style='background-color: #f0f0f0;'>")
            for kat in kategori_headers:
                html.append(f"<th style='padding: 8px; text-align: center; background-color: #90EE90;'>{kat}</th>")
            for kat in kategori_headers:
                html.append(f"<th style='padding: 8px; text-align: center; background-color: #FFB6C1;'>{kat}</th>")
            html.append("</tr>")
            
            # Data rows
            for fitur, kolom in fitur_list:
                if kolom not in data_uji.columns:
                    continue
                    
                indikator_to_kat = mapping_fitur[fitur]
                data_uji_fitur = data_uji.copy()
                if fitur == "Jumlah Anak":
                    data_uji_fitur['kategori_fitur'] = data_uji_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_uji_fitur['kategori_fitur'] = data_uji_fitur[kolom].map(indikator_to_kat)
                
                # Dapatkan kategori unik yang ada
                kategori_unik = list(sorted(set(data_uji_fitur['kategori_fitur'].dropna().unique())))
                
                # Untuk semua fitur, gunakan kategori yang ada dalam mapping
                if fitur == "Pekerjaan Ayah":
                    semua_kategori = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                    kategori_unik = [kat for kat in semua_kategori if kat in kategori_unik or kat in indikator_to_kat.values()]
                elif fitur == "Jumlah Anak":
                    semua_kategori = ["Rendah", "Sedang", "Tinggi", "Sangat Tinggi"]
                    kategori_unik = [kat for kat in semua_kategori if kat in kategori_unik or kat in indikator_to_kat.values()]
                else:
                    # Untuk fitur lain (Ibu Hamil, Disabilitas, Lansia), gunakan kategori dari mapping
                    kategori_unik = list(indikator_to_kat.values())
                
                html.append("<tr>")
                html.append(f"<td style='padding: 8px; font-weight: bold;'>{fitur}</td>")
                
                # Kolom Dapat (hijau)
                for kat in kategori_headers:
                    if kat in kategori_unik:
                        x_dapat = ((data_uji_fitur['kategori_fitur'] == kat) & (data_uji_fitur['kategori'] == 'Dapat')).sum()
                        n_dapat = (data_uji_fitur['kategori'] == 'Dapat').sum()
                        p_dapat = (x_dapat + 1) / (n_dapat + 1*(2)) if n_dapat > 0 else 0
                        value = f"{p_dapat:.2f}".replace('.', ',')
                    else:
                        value = ""
                    html.append(f"<td style='padding: 8px; text-align: center; background-color: #90EE90;'>{value}</td>")
                
                # Kolom Tidak Dapat (oranye)
                for kat in kategori_headers:
                    if kat in kategori_unik:
                        x_tidak = ((data_uji_fitur['kategori_fitur'] == kat) & (data_uji_fitur['kategori'] == 'Tidak dapat')).sum()
                        n_tidak = (data_uji_fitur['kategori'] == 'Tidak dapat').sum()
                        p_tidak = (x_tidak + 1) / (n_tidak + 1*(2)) if n_tidak > 0 else 0
                        value = f"{p_tidak:.2f}".replace('.', ',')
                    else:
                        value = ""
                    html.append(f"<td style='padding: 8px; text-align: center; background-color: #FFB6C1;'>{value}</td>")
                
                html.append("</tr>")
            
            html.append("</table>")
            html.append("</div>")

            # Section 14: Hasil Perhitungan data uji
            html.append("<div style='background:#FDF6B2;font-size:1.5em;font-weight:bold;padding:6px 8px; margin-bottom:24px;'>14. Hasil Perhitungan data uji</div>")
            # Hitung probabilitas kategori fitur dari data uji
            prob_kategori_uji = {}
            for fitur, kolom in fitur_list:
                if kolom not in data_uji.columns:
                    continue
                indikator_to_kat = mapping_fitur[fitur]
                data_uji_fitur = data_uji.copy()
                if fitur == "Jumlah Anak":
                    data_uji_fitur['kategori_fitur'] = data_uji_fitur[kolom].apply(kategori_jumlah_anak)
                else:
                    data_uji_fitur['kategori_fitur'] = data_uji_fitur[kolom].map(indikator_to_kat)
                prob_kategori_uji[fitur] = {}
                kategori_unik = list(sorted(set(data_uji_fitur['kategori_fitur'].dropna().unique())))
                for kat in kategori_unik:
                    x_dapat = ((data_uji_fitur['kategori_fitur'] == kat) & (data_uji_fitur['kategori'] == 'Dapat')).sum()
                    n_dapat = (data_uji_fitur['kategori'] == 'Dapat').sum()
                    p_dapat = (x_dapat + 1) / (n_dapat + 1*(2)) if n_dapat > 0 else 0
                    x_tidak = ((data_uji_fitur['kategori_fitur'] == kat) & (data_uji_fitur['kategori'] == 'Tidak dapat')).sum()
                    n_tidak = (data_uji_fitur['kategori'] == 'Tidak dapat').sum()
                    p_tidak = (x_tidak + 1) / (n_tidak + 1*(2)) if n_tidak > 0 else 0
                    prob_kategori_uji[fitur][kat] = {
                        'Dapat': p_dapat,
                        'Tidak dapat': p_tidak
                    }
            hasil_perhitungan_uji = []
            for idx, (_, row) in enumerate(data_uji.iterrows(), 1):
                no = idx
                nama = row['nama']
                p_dapat_x = prob_uji_dapat
                p_tidak_x = prob_uji_tidak
                for fitur, kolom in fitur_list:
                    if kolom not in row:
                        continue
                    if fitur == "Jumlah Anak":
                        kategori = kategori_jumlah_anak(row[kolom])
                    else:
                        nilai_fitur = str(row[kolom])
                        indikator_to_kat = mapping_fitur[fitur]
                        kategori = indikator_to_kat.get(nilai_fitur)
                    if kategori is None:
                        continue
                    if fitur in prob_kategori_uji and kategori in prob_kategori_uji[fitur]:
                        prob_dapat = prob_kategori_uji[fitur][kategori]['Dapat']
                        prob_tidak = prob_kategori_uji[fitur][kategori]['Tidak dapat']
                        bobot = bobot_fitur[kolom]
                        p_dapat_x *= prob_dapat ** bobot
                        p_tidak_x *= prob_tidak ** bobot
                
                p_dapat_x_rounded = math.ceil(p_dapat_x * 1000) / 1000
                p_tidak_x_rounded = math.ceil(p_tidak_x * 1000) / 1000
                
                # Status prediksi
                if p_tidak_x_rounded < p_dapat_x_rounded:
                    status_prediksi = "Dapat"
                else:
                    status_prediksi = "Tidak dapat"
                
                # Status aktual dari data
                status_aktual = row['kategori']
                
                hasil_perhitungan_uji.append([
                    no,
                    nama,
                    status_aktual,
                    f"{p_dapat_x_rounded:.3f}".replace('.', ','),
                    f"{p_tidak_x_rounded:.3f}".replace('.', ','),
                    status_prediksi
                ])
            df_hasil_uji = pd.DataFrame(
                hasil_perhitungan_uji,
                columns=[
                    "No", "Nama", "Status Aktual",
                    "P (Dapat | X)",
                    "P (Tidak dapat | X)",
                    "Status Prediksi"
                ]
            )
            html.append(df_hasil_uji.to_html(index=False, border=1))
    return '\n'.join(html)


def perhitungan_metode_view(user_state):
    from lib.auth import get_user_role
    import gradio as gr
    from views.kelola_data import map_ibu_hamil, map_disabilitas, map_lansia
    import pandas as pd
    from lib import database

    def fetch_table():
        try:
            df = database.fetch_all_masyarakat()
            if df.empty:
                return pd.DataFrame(columns=['no', 'id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'kategori'])
            if 'ibu_hamil' in df.columns:
                df['ibu_hamil'] = df['ibu_hamil'].apply(map_ibu_hamil)
            if 'disabilitas' in df.columns:
                df['disabilitas'] = df['disabilitas'].apply(map_disabilitas)
            if 'lansia' in df.columns:
                df['lansia'] = df['lansia'].apply(map_lansia)
            n = len(df)
            df.insert(0, 'no', range(n, 0, -1))
            return df
        except Exception:
            return pd.DataFrame(columns=['no', 'id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'kategori'])

    role = get_user_role(user_state)
    with gr.Column():
        perhitungan_container = gr.Group(visible=False)
        unauthorized_message = gr.Markdown("🔒 Silakan login terlebih dahulu untuk mengakses fitur aksi, lalu klik refresh", visible=True)
        not_kepala_message = gr.Markdown("🚫 **Hanya kepala yang dapat mengakses halaman Perhitungan Metode.**", visible=False)
        refresh_visibility_btn = gr.Button("🔄 Refresh Visibility", size="sm")

    def update_perhitungan_ui():
        current_role = get_user_role(user_state)
        if current_role == "unauthorized":
            return gr.update(visible=True), gr.update(visible=False), gr.update(visible=False), gr.update(visible=False)
        elif current_role != "kepala":
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False), gr.update(visible=False)
        else:
            return gr.update(visible=False), gr.update(visible=False), gr.update(visible=True), gr.update(visible=True)

    refresh_visibility_btn.click(fn=update_perhitungan_ui, outputs=[unauthorized_message, not_kepala_message, perhitungan_container, refresh_visibility_btn])

    with perhitungan_container:
        refresh_btn = gr.Button("🔄 Refresh", size="sm")
        perhitungan_output = gr.Markdown(perhitungan_html(fetch_table))
        refresh_btn.click(fn=lambda: perhitungan_html(fetch_table), outputs=perhitungan_output)

