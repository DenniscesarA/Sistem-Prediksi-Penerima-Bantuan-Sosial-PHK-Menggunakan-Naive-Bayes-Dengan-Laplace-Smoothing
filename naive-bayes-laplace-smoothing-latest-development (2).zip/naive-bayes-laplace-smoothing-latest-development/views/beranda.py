import gradio as gr
from lib.auth import get_user_role

def beranda_view(user_state):
    # Debug: show current role
    return f"""
    # Selamat Datang!
    Aplikasi ini dirancang untuk memprediksi kelayakan penerima bantuan PKH berdasarkan kriteria tertentu
    menggunakan algoritma Naive Bayes dengan Laplace Smoothing.

    **Fitur Utama:**
    - Kelola Data: Tambah, hapus, edit, dan pratinjau data masyarakat
    - Prediksi: Masukkan data untuk prediksi kelayakan PKH
    - Riwayat: Lihat hasil prediksi sebelumnya
    - Evaluasi: Lihat performa model (confusion matrix & akurasi)
    """ 