import gradio as gr
from lib.auth import get_user_role
from lib import database
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
import seaborn as sns
import matplotlib.pyplot as plt
import io
import base64
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import tempfile
import os

def evaluasi_view(user_state):
    def check_access():
        """Check current user access dynamically"""
        role = get_user_role(user_state)
        return role
    
    # Check initial access
    role = check_access()
    
    # Main container with debug alert
    with gr.Column():
        # Container untuk konten evaluasi
        evaluasi_container = gr.Group(visible=False)
        unauthorized_message = gr.Markdown("🔒 Silakan login terlebih dahulu untuk mengakses fitur aksi, lalu klik refresh", visible=True)
        not_kepala_message = gr.Markdown("🚫 **Hanya kepala yang dapat mengakses evaluasi model**", visible=False)
        refresh_visibility_btn = gr.Button("🔄 Refresh Visibility", size="sm")
    
    if role == "unauthorized":
        unauthorized_message.visible = True
        evaluasi_container.visible = False
        not_kepala_message.visible = False
    elif role != "kepala":
        unauthorized_message.visible = False
        evaluasi_container.visible = False
        not_kepala_message.visible = True
    else:  # role == "kepala"
        unauthorized_message.visible = False
        evaluasi_container.visible = True
        not_kepala_message.visible = False
    
    # Evaluasi content (only visible for kepala)
    with evaluasi_container:
        def evaluasi_model():
            # Check auth again before running evaluation
            current_role = check_access()
            if current_role != "kepala":
                return "🚫 **Hanya kepala yang dapat mengakses evaluasi model**", None
            # Ambil data prediksi yang sudah disetujui kepala
            df = database.fetch_validated_prediksi()
            if len(df) < 5:
                return "Data prediksi yang sudah disetujui belum cukup untuk evaluasi, Minimal 5 data prediksi yang sudah disetujui.", None
            # Parse status prediksi dari kolom 'hasil' (misal: 'Status: Dapat' atau 'Status: Tidak dapat')
            def parse_status(hasil):
                if isinstance(hasil, str) and 'Status:' in hasil:
                    if 'Dapat' in hasil.split('Status:')[-1]:
                        return 'Dapat'
                    else:
                        return 'Tidak dapat'
                return 'Tidak dapat'
            y_pred = df['hasil'].apply(parse_status).values
            # Gunakan label_aktual valid jika ada, jika tidak fallback ke prediksi (untuk kompatibilitas lama)
            def normalize_label(val):
                if isinstance(val, str):
                    v = val.strip().lower()
                    if v in ['dapat', 'tidak dapat']:
                        return 'Dapat' if v == 'dapat' else 'Tidak dapat'
                return None
            if 'label_aktual' in df.columns:
                y_true_series = df['label_aktual'].apply(normalize_label)
                # Fallback ke prediksi untuk baris yang tidak valid
                y_true = np.where(y_true_series.isna(), y_pred, y_true_series.values)
            else:
                y_true = y_pred.copy()
            akurasi = accuracy_score(y_true, y_pred)
            presisi = precision_score(y_true, y_pred, average='weighted', zero_division=0)
            recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
            f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0)
            cm = confusion_matrix(y_true, y_pred, labels=['Dapat', 'Tidak dapat'])
            # Buat tabel confusion matrix HTML dengan keterangan TP, TN, FP, FN
            cm_table_html = f'''
            <table border="1" style="border-collapse:collapse;text-align:center;margin:auto;">
                <tr><th></th><th>Prediksi Dapat</th><th>Prediksi Tidak Dapat</th></tr>
                <tr><th>Aktual Dapat</th><td style="background-color:#d4edda;color:#155724;"><b>{cm[0][0]}</b><br><small>TP (True Positive)</small></td><td style="background-color:#f8d7da;color:#721c24;"><b>{cm[0][1]}</b><br><small>FN (False Negative)</small></td></tr>
                <tr><th>Aktual Tidak Dapat</th><td style="background-color:#f8d7da;color:#721c24;"><b>{cm[1][0]}</b><br><small>FP (False Positive)</small></td><td style="background-color:#d4edda;color:#155724;"><b>{cm[1][1]}</b><br><small>TN (True Negative)</small></td></tr>
            </table>
            <br>
            <div style="text-align:center;font-size:12px;">
                <span style="background-color:#d4edda;color:#155724;padding:2px 8px;margin:0 5px;">Hijau = Prediksi Benar</span>
                <span style="background-color:#f8d7da;color:#721c24;padding:2px 8px;margin:0 5px;">Merah = Prediksi Salah</span>
            </div>
            '''
            # Penjelasan dinamis berbasis data evaluasi
            tp = cm[0][0]  # True Positive
            tn = cm[1][1]  # True Negative
            fp = cm[1][0]  # False Positive
            fn = cm[0][1]  # False Negative
            
            # Hitung perhitungan detail
            total = tp + tn + fp + fn
            akurasi_calc = f"({tp} + {tn}) / ({tp} + {tn} + {fp} + {fn}) = {tp + tn} / {total} = {(tp + tn) / total:.4f}"
            presisi_calc = f"{tp} / ({tp} + {fp}) = {tp} / {tp + fp} = {tp / (tp + fp):.4f}" if (tp + fp) > 0 else "0 / 0 = 0.0000"
            recall_calc = f"{tp} / ({tp} + {fn}) = {tp} / {tp + fn} = {tp / (tp + fn):.4f}" if (tp + fn) > 0 else "0 / 0 = 0.0000"
            f1_calc = f"2 * ({presisi:.4f} * {recall:.4f}) / ({presisi:.4f} + {recall:.4f}) = {2 * (presisi * recall) / (presisi + recall):.4f}" if (presisi + recall) > 0 else "0.0000"
            
            penjelasan_html = f'''
            <div style='margin-bottom:16px;'>
            <b>Penjelasan Evaluasi Model (berdasarkan data aktual):</b><br>
            - <b>Confusion Matrix</b>: Tabel di bawah menunjukkan jumlah prediksi benar dan salah untuk masing-masing kelas berdasarkan data prediksi yang sudah divalidasi.<br>
            <br>
            <b>Rumus dan Perhitungan:</b><br>
            - <b>Akurasi</b> = (TP + TN) / (TP + TN + FP + FN) = {akurasi_calc} = <b>{(akurasi*100):.2f}%</b><br>
            - <b>Presisi</b> = TP / (TP + FP) = {presisi_calc} = <b>{presisi:.4f}</b><br>
            - <b>Recall</b> = TP / (TP + FN) = {recall_calc} = <b>{recall:.4f}</b><br>
            - <b>F1-Score</b> = 2 * (Presisi * Recall) / (Presisi + Recall) = {f1_calc} = <b>{f1:.4f}</b><br>
            <br>
            <b>Confusion Matrix Aktual:</b><br>
            {cm_table_html}
            <br>
            <b>Keterangan Detail:</b><br>
            - <b>TP (True Positive):</b> Aktual Dapat & diprediksi Dapat = {tp} (prediksi benar untuk kelas "Dapat")<br>
            - <b>TN (True Negative):</b> Aktual Tidak Dapat & diprediksi Tidak Dapat = {tn} (prediksi benar untuk kelas "Tidak Dapat")<br>
            - <b>FP (False Positive):</b> Aktual Tidak Dapat & diprediksi Dapat = {fp} (prediksi salah - seharusnya "Tidak Dapat" tapi diprediksi "Dapat")<br>
            - <b>FN (False Negative):</b> Aktual Dapat & diprediksi Tidak Dapat = {fn} (prediksi salah - seharusnya "Dapat" tapi diprediksi "Tidak Dapat")<br>
            <br>
            <b>Total Data:</b> {total} (TP + TN + FP + FN)<br>
            <b>Prediksi Benar:</b> {tp + tn} (TP + TN)<br>
            <b>Prediksi Salah:</b> {fp + fn} (FP + FN)<br>
            </div>
            '''
            plt.figure(figsize=(6, 4))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Dapat', 'Tidak dapat'], yticklabels=['Dapat', 'Tidak dapat'])
            plt.title('Confusion Matrix')
            plt.xlabel('Prediksi')
            plt.ylabel('Aktual')
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            img_str = base64.b64encode(buf.getvalue()).decode()
            plt.close()
            html_output = f"""
            {penjelasan_html}
            <div style='text-align: center;'>
                <h3>Evaluasi Model</h3>
                <p><strong>Akurasi:</strong> {akurasi*100:.2f}%<br>
                <strong>Presisi:</strong> {presisi:.2f}<br>
                <strong>Recall:</strong> {recall:.2f}<br>
                <strong>F1-Score:</strong> {f1:.2f}</p>
                <h4>Visualisasi Confusion Matrix:</h4>
                <img src='data:image/png;base64,{img_str}' style='max-width: 80%; display: block; margin: 0 auto;'>
            </div>
            """
            return html_output, None
        
        eval_btn = gr.Button("Klik Disini untuk melihat Diagram Evaluasi Model")
        eval_html = gr.HTML()
        eval_btn.click(fn=evaluasi_model, outputs=eval_html)
        # Tombol refresh data evaluasi di paling atas
        # refresh_eval_btn = gr.Button("🔄 Refresh Data Evaluasi", size="sm")
        # refresh_eval_btn.click(fn=evaluasi_model, outputs=eval_html)
        
        def generate_pdf_report():
            """Generate PDF report of evaluation results"""
            # Check auth again before printing
            current_role = check_access()
            if current_role != "kepala":
                return "🚫 **Hanya kepala yang dapat mengakses evaluasi model**", None
            try:
                # Get data prediksi yang sudah disetujui kepala
                df = database.fetch_validated_prediksi()
                if len(df) < 5:
                    return "Data prediksi yang sudah disetujui belum cukup untuk evaluasi.", None
                def parse_status(hasil):
                    if isinstance(hasil, str) and 'Status:' in hasil:
                        if 'Dapat' in hasil.split('Status:')[-1]:
                            return 'Dapat'
                        else:
                            return 'Tidak dapat'
                    return 'Tidak dapat'
                y_pred = df['hasil'].apply(parse_status).values
                # Gunakan label_aktual jika ada, jika tidak fallback ke prediksi (untuk kompatibilitas lama)
                if 'label_aktual' in df.columns and df['label_aktual'].notna().any():
                    y_true = df['label_aktual'].fillna('Tidak dapat').values
                else:
                    y_true = y_pred.copy()
                akurasi = accuracy_score(y_true, y_pred)
                presisi = precision_score(y_true, y_pred, average='weighted', zero_division=0)
                recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
                f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0)
                cm = confusion_matrix(y_true, y_pred, labels=['Dapat', 'Tidak dapat'])
                # Create confusion matrix image
                plt.figure(figsize=(8, 6))
                sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                           xticklabels=['Dapat', 'Tidak dapat'], 
                           yticklabels=['Dapat', 'Tidak dapat'])
                plt.title('Confusion Matrix')
                plt.xlabel('Prediksi')
                plt.ylabel('Aktual')
                cm_img_path = tempfile.mktemp(suffix='.png')
                plt.savefig(cm_img_path, format='png', dpi=300, bbox_inches='tight')
                plt.close()
                # Create PDF
                pdf_path = tempfile.mktemp(suffix='.pdf')
                doc = SimpleDocTemplate(pdf_path, pagesize=A4)
                styles = getSampleStyleSheet()
                story = []
                # Title
                title_style = ParagraphStyle(
                    'CustomTitle',
                    parent=styles['Heading1'],
                    fontSize=24,
                    spaceAfter=30,
                    alignment=1  # Center alignment
                )
                story.append(Paragraph("LAPORAN EVALUASI MODEL PREDIKSI PKH", title_style))
                story.append(Spacer(1, 20))
                # Subtitle
                subtitle_style = ParagraphStyle(
                    'Subtitle',
                    parent=styles['Heading2'],
                    fontSize=16,
                    spaceAfter=20,
                    alignment=1
                )
                story.append(Paragraph("Sistem Prediksi Kelayakan Bantuan PKH", subtitle_style))
                story.append(Spacer(1, 30))
                # Data Summary
                story.append(Paragraph("Ringkasan Data", styles['Heading2']))
                story.append(Spacer(1, 12))
                data_summary = [
                    ["Total Data", str(len(df))],
                    ["Tanggal Evaluasi", pd.Timestamp.now().strftime('%d/%m/%Y %H:%M')]
                ]
                summary_table = Table(data_summary, colWidths=[2*inch, 2*inch])
                summary_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(summary_table)
                story.append(Spacer(1, 20))
                # Model Performance
                story.append(Paragraph("Performa Model", styles['Heading2']))
                story.append(Spacer(1, 12))
                
                # Hitung perhitungan detail untuk PDF
                tp = cm[0][0]
                tn = cm[1][1]
                fp = cm[1][0]
                fn = cm[0][1]
                total = tp + tn + fp + fn
                
                performance_data = [
                    ["Metrik", "Rumus", "Perhitungan", "Nilai"],
                    ["Akurasi", "(TP + TN) / (TP + TN + FP + FN)", f"({tp} + {tn}) / {total}", f"{akurasi*100:.2f}%"],
                    ["Presisi", "TP / (TP + FP)", f"{tp} / ({tp} + {fp})", f"{presisi:.4f}"],
                    ["Recall", "TP / (TP + FN)", f"{tp} / ({tp} + {fn})", f"{recall:.4f}"],
                    ["F1-Score", "2 * (P * R) / (P + R)", f"2 * ({presisi:.4f} * {recall:.4f}) / ({presisi:.4f} + {recall:.4f})", f"{f1:.4f}"]
                ]
                perf_table = Table(performance_data, colWidths=[1.2*inch, 1.5*inch, 1.5*inch, 0.8*inch])
                perf_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(perf_table)
                story.append(Spacer(1, 20))
                # Confusion Matrix
                story.append(Paragraph("Confusion Matrix", styles['Heading2']))
                story.append(Spacer(1, 12))
                img = Image(cm_img_path, width=4*inch, height=3*inch)
                story.append(img)
                story.append(Spacer(1, 20))
                # Confusion Matrix Table dengan keterangan TP, TN, FP, FN
                cm_data = [
                    ["", "Prediksi Dapat", "Prediksi Tidak Dapat"],
                    ["Aktual Dapat", f"{cm[0][0]}\n(TP)", f"{cm[0][1]}\n(FN)"],
                    ["Aktual Tidak Dapat", f"{cm[1][0]}\n(FP)", f"{cm[1][1]}\n(TN)"]
                ]
                cm_table = Table(cm_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch])
                cm_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(cm_table)
                story.append(Spacer(1, 20))
                
                # Detail TP, TN, FP, FN
                tp = cm[0][0]
                tn = cm[1][1]
                fp = cm[1][0]
                fn = cm[0][1]
                total = tp + tn + fp + fn
                
                detail_data = [
                    ["Keterangan", "Nilai", "Penjelasan"],
                    ["TP (True Positive)", str(tp), "Aktual Dapat & diprediksi Dapat"],
                    ["TN (True Negative)", str(tn), "Aktual Tidak Dapat & diprediksi Tidak Dapat"],
                    ["FP (False Positive)", str(fp), "Aktual Tidak Dapat & diprediksi Dapat"],
                    ["FN (False Negative)", str(fn), "Aktual Dapat & diprediksi Tidak Dapat"],
                    ["Total Data", str(total), "TP + TN + FP + FN"],
                    ["Prediksi Benar", str(tp + tn), "TP + TN"],
                    ["Prediksi Salah", str(fp + fn), "FP + FN"]
                ]
                detail_table = Table(detail_data, colWidths=[1.2*inch, 0.8*inch, 2.5*inch])
                detail_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('FONTSIZE', (0, 1), (-1, -1), 9)
                ]))
                story.append(detail_table)
                story.append(Spacer(1, 30))
                
                # Tabel Riwayat Prediksi
                story.append(Paragraph("Data Riwayat Prediksi", styles['Heading2']))
                story.append(Spacer(1, 12))
                
                # Ambil data riwayat prediksi yang sudah disetujui
                riwayat_df = database.fetch_validated_prediksi()
                if not riwayat_df.empty:
                    # Format data untuk tabel
                    riwayat_data = []
                    # Header
                    riwayat_data.append(["No", "Nama", "Pekerjaan Ayah", "Jumlah Anak", "Ibu Hamil", "Disabilitas", "Lansia", "Status Prediksi", "Status Aktual"])
                    
                    # Parse status prediksi dari hasil
                    def parse_status_prediksi(hasil):
                        if isinstance(hasil, str) and 'Status:' in hasil:
                            return hasil.split('Status:')[-1].strip()
                        return 'Tidak dapat'
                    
                    # Format data riwayat
                    for idx, row in riwayat_df.iterrows():
                        status_prediksi = parse_status_prediksi(row['hasil'])
                        status_aktual = row.get('label_aktual', 'Tidak tersedia')
                        
                        riwayat_data.append([
                            str(idx + 1),
                            str(row['nama']),
                            str(row['pekerjaan_ayah']),
                            str(row['jumlah_anak']),
                            "Ya" if row['ibu_hamil'] == 1 else "Tidak",
                            "Ya" if row['disabilitas'] == 1 else "Tidak",
                            "Ya" if row['lansia'] == 1 else "Tidak",
                            status_prediksi,
                            status_aktual
                        ])
                    
                    # Buat tabel riwayat dengan kolom yang lebih kecil
                    col_widths = [0.3*inch, 1.2*inch, 1.2*inch, 0.8*inch, 0.6*inch, 0.6*inch, 0.6*inch, 1.0*inch, 1.0*inch]
                    riwayat_table = Table(riwayat_data, colWidths=col_widths)
                    riwayat_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, 0), 8),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                        ('FONTSIZE', (0, 1), (-1, -1), 7),
                        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.beige, colors.white])
                    ]))
                    story.append(riwayat_table)
                else:
                    story.append(Paragraph("Tidak ada data riwayat prediksi yang tersedia.", styles['Normal']))
                
                story.append(Spacer(1, 30))
                # Conclusion
                story.append(Paragraph("Kesimpulan", styles['Heading2']))
                story.append(Spacer(1, 12))
                conclusion_text = f"""
                Berdasarkan evaluasi model yang telah dilakukan, dapat disimpulkan bahwa:
                • Model memiliki akurasi sebesar {akurasi*100:.2f}%
                • Presisi model sebesar {presisi:.4f}
                • Recall model sebesar {recall:.4f}
                • F1-Score model sebesar {f1:.4f}
                Model ini dapat digunakan untuk memprediksi kelayakan bantuan PKH dengan tingkat keakuratan yang cukup baik.
                """
                story.append(Paragraph(conclusion_text, styles['Normal']))
                # Build PDF
                doc.build(story)
                # Clean up temporary image file
                os.remove(cm_img_path)
                return f"✅ **PDF berhasil dibuat!** File: {os.path.basename(pdf_path)}, Silakan klik tombol angka (contoh. 85KB) di dibawah untuk mengunduh laporan evaluasi model.", pdf_path
            except Exception as e:
                return f"❌ **Error generating PDF:** {str(e)}", None
        
        print_btn = gr.Button("📄Klik Disini untuk Download Laporan Evaluasi Model")
        print_status = gr.Textbox(label="Status PDF", interactive=False)
        pdf_download = gr.File(label="Download PDF Report")
        
        print_btn.click(fn=generate_pdf_report, outputs=[print_status, pdf_download])
    
    # Function to update UI based on current role
    def update_evaluasi_ui():
        """Update evaluasi UI based on current user role"""
        current_role = check_access()
        
        if current_role == "unauthorized":
            return gr.update(visible=True), gr.update(visible=False), gr.update(visible=False), gr.update(visible=False)
        elif current_role != "kepala":
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False), gr.update(visible=False)
        else:  # role == "kepala"
            return gr.update(visible=False), gr.update(visible=False), gr.update(visible=True), gr.update(visible=True)
    
    # Add refresh button for evaluasi
    refresh_visibility_btn.click(fn=update_evaluasi_ui, outputs=[unauthorized_message, not_kepala_message, evaluasi_container, refresh_visibility_btn]) 