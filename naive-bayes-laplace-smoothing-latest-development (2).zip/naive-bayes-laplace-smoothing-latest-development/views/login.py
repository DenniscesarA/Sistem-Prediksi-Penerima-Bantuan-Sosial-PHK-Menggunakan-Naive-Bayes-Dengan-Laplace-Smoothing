import gradio as gr
from lib import database
from lib.auth import save_session, clear_session, load_session

def create_login_components(user_state, trigger_visibility_update=None):
    """Create login components and return them along with handlers"""

    def handle_login(username_val, password_val):
        if not username_val or not password_val:
            return (
                "❌ **Username dan password harus diisi**",
                gr.update(visible=True),
                gr.update(),
                gr.update(visible=False),
                gr.update(visible=False),  # Perhitungan Metode tab disembunyikan
                gr.update(visible=False)   # Evaluasi tab disembunyikan
            )
        if len(username_val.strip()) < 3:
            return (
                "❌ **Username minimal 3 karakter**",
                gr.update(visible=True),
                gr.update(),
                gr.update(visible=False),
                gr.update(visible=False),  # Perhitungan Metode tab disembunyikan
                gr.update(visible=False)   # Evaluasi tab disembunyikan
            )
        if len(password_val) < 4:
            return (
                "❌ **Password minimal 4 karakter**",
                gr.update(visible=True),
                gr.update(),
                gr.update(visible=False),
                gr.update(visible=False),  # Perhitungan Metode tab disembunyikan
                gr.update(visible=False)   # Evaluasi tab disembunyikan
            )

        user = database.authenticate_user(username_val.strip(), password_val)
        if user:
            user_data = {"role": user["role"], "username": user["username"]}
            save_session(user_data)
            user_state.value = user_data

            role_messages = {
                "masyarakat": f"✅ **Login berhasil!** Selamat datang {user['username']} (Masyarakat)",
                "pegawai": f"✅ **Login berhasil!** Selamat datang {user['username']} (Pegawai)",
                "kepala": f"✅ **Login berhasil!** Selamat datang {user['username']} (Kepala)"
            }
            success_message = role_messages.get(user["role"], f"✅ **Login berhasil!** Selamat datang {user['username']}")

            return (
                success_message,
                gr.update(visible=False),
                gr.update(value=f"Halo, {user['username']} ({user['role']})"),
                gr.update(visible=True),
                gr.update(visible=user["role"] == "kepala"),  # Perhitungan Metode hanya untuk kepala
                gr.update(visible=user["role"] == "kepala")   # Evaluasi hanya untuk kepala
            )
        else:
            return (
                "❌ **Username atau password salah!** Silakan coba lagi.",
                gr.update(visible=True),
                gr.update(value=""),
                gr.update(visible=False),
                gr.update(visible=False),  # Perhitungan Metode tab disembunyikan
                gr.update(visible=False)   # Evaluasi tab disembunyikan
            )

    def do_logout():
        user_state.value = {"role": "unauthorized", "username": None}
        clear_session()
        return (
            gr.update(value=""),
            gr.update(visible=False),
            gr.update(visible=True),
            gr.update(visible=False),  # Perhitungan Metode tab disembunyikan
            gr.update(visible=False)   # Evaluasi tab disembunyikan
        )

    def clear_error():
        return gr.update(visible=False, value="")

    def init_ui():
        session_data = load_session()
        if session_data and session_data.get("role") != "unauthorized" and session_data.get("username"):
            user_state.value = session_data
            status = f"Halo, {session_data['username']} ({session_data['role']})"
            return (
                gr.update(value=status),
                gr.update(visible=True),
                gr.update(visible=False),
                gr.update(visible=session_data["role"] == "kepala"),  # Perhitungan Metode hanya untuk kepala
                gr.update(visible=session_data["role"] == "kepala")   # Evaluasi hanya untuk kepala
            )
        user_state.value = {"role": "unauthorized", "username": None}
        return (
            gr.update(value=""),
            gr.update(visible=False),
            gr.update(visible=True),
            gr.update(visible=False),  # Perhitungan Metode tab disembunyikan
            gr.update(visible=False)   # Evaluasi tab disembunyikan
        )

    # UI Components
    with gr.Column(elem_classes=["login-container"]) as login_container:
        gr.Markdown("# 🔐 Login")
        gr.Markdown("Silakan login untuk mengakses aplikasi")
        gr.Markdown("""
        **Role yang tersedia:**
        - **Masyarakat**: Hanya dapat melihat data dan prediksi  
        - **Pegawai**: Dapat mengelola data dan prediksi  
        - **Kepala**: Akses penuh termasuk evaluasi model
        """)
        with gr.Column():
            username = gr.Textbox(label="Username", placeholder="Masukkan username (min. 3 karakter)", scale=1)
            password = gr.Textbox(label="Password", type="password", placeholder="Masukkan password (min. 4 karakter)", scale=1)
            login_btn = gr.Button("Login", variant="primary", size="lg")
            login_error = gr.Markdown("", visible=False, elem_classes=["error-message"])

    # Event handlers akan di-bind di app.py untuk menghindari konflik
    # Tidak ada event binding di sini

    return {
        'login_container': login_container,
        'username': username,
        'password': password,
        'login_btn': login_btn,
        'login_error': login_error,
        'handle_login': handle_login,
        'do_logout': do_logout,
        'clear_error': clear_error,
        'init_ui': init_ui,
        'trigger_refresh': lambda: None
    }

def login_view():
    pass
