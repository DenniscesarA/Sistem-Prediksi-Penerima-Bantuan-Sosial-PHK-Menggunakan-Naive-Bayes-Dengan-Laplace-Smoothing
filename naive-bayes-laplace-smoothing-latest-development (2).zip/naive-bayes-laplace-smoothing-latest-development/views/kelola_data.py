import gradio as gr
from lib import database
from lib.auth import get_user_role
import pandas as pd

def extract_id(selected_value):
    if selected_value and selected_value.startswith("id:"):
        return int(selected_value.split(",")[0].replace("id:", "").strip())
    return None

def map_ibu_hamil(val):
    if val is None or str(val).strip() == "":
        return ""
    if str(val) == "1":
        return "Tidak"
    elif str(val) == "2":
        return "Ya"
    return val

def map_disabilitas(val):
    if val is None or str(val).strip() == "":
        return ""
    if str(val) == "1":
        return "Tidak"
    elif str(val) == "2":
        return "Ya"
    return val

def map_lansia(val):
    if val is None or str(val).strip() == "":
        return ""
    if str(val) == "1":
        return "Tidak"
    elif str(val) == "2":
        return "Ya"
    return val

def kelola_data_view(user_state):
    selected_data = gr.State(None)

    def fetch_table():
        try:
            df = database.fetch_all_masyarakat()
            if df.empty:
                return pd.DataFrame(columns=['no', 'id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'kategori'])
            # Mapping per kolom
            if 'ibu_hamil' in df.columns:
                df['ibu_hamil'] = df['ibu_hamil'].apply(map_ibu_hamil)
            if 'disabilitas' in df.columns:
                df['disabilitas'] = df['disabilitas'].apply(map_disabilitas)
            if 'lansia' in df.columns:
                df['lansia'] = df['lansia'].apply(map_lansia)
            # Kolom no: nomor 1 di bawah, nomor terbesar di atas
            n = len(df)
            df.insert(0, 'no', range(n, 0, -1))
            return df
        except Exception:
            return pd.DataFrame(columns=['no', 'id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'kategori'])

    with gr.Column():
        # Search and action buttons row
        with gr.Row():
            with gr.Column(scale=2):
                search_box = gr.Textbox(
                    label="🔍 Cari Data",
                    placeholder="Masukkan nama, pekerjaan, atau kategori...",
                    scale=1
                )
                gr.Markdown("💡 **Catatan**: pencarian bisa berdasarkan nama, pekerjaan ayah, atau kategori data")
            with gr.Column(scale=1):
                with gr.Row():
                    search_btn = gr.Button("🔎 Cari", variant="secondary", size="sm")
                    clear_search_btn = gr.Button("❌ Clear", size="sm")
                    refresh_data_btn = gr.Button("🔄 Refresh Data", size="sm")
                    # refresh_btn = gr.Button("🔄 Refresh", size="sm")
                    refresh_visibility_btn = gr.Button("🔄 Refresh Tombol Aksi", size="sm")
            with gr.Column(scale=3):
                with gr.Row():
                    tambah_btn = gr.Button("📑 Tambah Data", variant="primary", size="sm", visible=False)        # Biru
                    hapus_btn = gr.Button("⛏️ Hapus", variant="stop", size="sm", visible=False)                 # Merah
                    edit_btn = gr.Button("📝 Edit", variant="primary", size="sm", visible=False)              # Abu-abu
                    bulk_delete_btn = gr.Button("🗑️ Hapus Banyak", variant="stop", size="sm", visible=False)     # Merah
                    import_btn = gr.UploadButton("📥 Import CSV", variant="primary", file_types=[".csv"], size="sm", visible=False) # Default (abu terang)
                    hapus_semua_btn = gr.Button("💀 Hapus Semua Data", variant="stop", size="sm", visible=False)
                    # export_btn = gr.Button("📤 Export CSV", variant="secondary", size="sm", visible=False)       # Abu-abu (hapus)
                    login_message = gr.Markdown("🔒 **Silakan login terlebih dahulu untuk mengakses fitur aksi, lalu klik refresh**", visible=True)

        with gr.Column():
            status_box = gr.Textbox(label="Status Operasi", interactive=False, visible=False)
            download_file = gr.File(label="Download CSV", visible=False)
        with gr.Group(visible=False) as modal_tambah:
            gr.Markdown("## ➕ Tambah Data Baru")
            with gr.Row():
                tambah_nama = gr.Textbox(label="Nama", placeholder="Masukkan nama lengkap", scale=1)
                tambah_pekerjaan_ayah = gr.Dropdown(
                    ['Tidak Bekerja', 'Buruh', 'Mengurus Rumah', 'Karyawan', 'PNS'],
                    label="Pekerjaan Ayah",
                    value='Tidak Bekerja',
                    scale=1
                )
                tambah_jumlah_anak = gr.Number(label="Jumlah Anak", minimum=0, value=0, step=1, scale=1)
                tambah_ibu_hamil = gr.Dropdown(
                    choices=["Tidak", "Ya"],
                    label="Ibu Hamil",
                    value="Tidak",
                    scale=1
                )
                tambah_disabilitas = gr.Dropdown(
                    choices=["Tidak", "Ya"],
                    label="Disabilitas",
                    value="Tidak",
                    scale=1
                )
                tambah_lansia = gr.Dropdown(
                    choices=["Tidak", "Ya"],
                    label="Lansia",
                    value="Tidak",
                    scale=1
                )
                tambah_kategori = gr.Dropdown(
                    choices=["Tidak Dapat", "Dapat"],
                    label="Kategori",
                    value="Tidak Dapat",
                    scale=1
                )
            with gr.Row():
                simpan_tambah = gr.Button("💾 Simpan", variant="primary", size="sm")
                batal_tambah = gr.Button("❌ Batal", size="sm")

        with gr.Group(visible=False) as modal_edit:
            gr.Markdown("## ✏️ Edit Data")
            edit_id = gr.Dropdown(
                choices=[],
                label="Pilih ID Data untuk Diedit",
                interactive=True
            )
            with gr.Row():
                edit_nama = gr.Textbox(label="Nama", scale=2)
                edit_pekerjaan_ayah = gr.Dropdown(
                    ['Tidak Bekerja', 'Buruh', 'Mengurus Rumah', 'Karyawan', 'PNS'],
                    label="Pekerjaan Ayah",
                    scale=1
                )
                edit_jumlah_anak = gr.Number(label="Jumlah Anak", minimum=0, step=1, scale=1)
                edit_ibu_hamil = gr.Dropdown(
                    choices=["Tidak", "Ya"],
                    label="Ibu Hamil",
                    scale=1
                )
                edit_disabilitas = gr.Dropdown(
                    choices=["Tidak", "Ya"],
                    label="Disabilitas",
                    scale=1
                )
                edit_lansia = gr.Dropdown(
                    choices=["Tidak", "Ya"],
                    label="Lansia",
                    scale=1
                )
                edit_kategori = gr.Dropdown(
                    choices=["Tidak Dapat", "Dapat"],
                    label="kategori",
                    scale=1
                )
            with gr.Row():
                simpan_edit = gr.Button("💾 Simpan Perubahan", variant="primary", size="sm")
                batal_edit = gr.Button("❌ Batal", size="sm")

        with gr.Group(visible=False) as modal_hapus:
            gr.Markdown("## 🗑️ Hapus Data")
            hapus_id = gr.Dropdown(
                choices=[],
                label="Pilih ID Data untuk Dihapus",
                interactive=True
            )
            with gr.Row():
                konfirmasi_hapus = gr.Button("🗑️ Konfirmasi Hapus", variant="stop", size="sm")
                batal_hapus = gr.Button("❌ Batal", size="sm")

        with gr.Group(visible=False) as modal_bulk_delete:
            gr.Markdown("## 🗑️ Bulk Delete Data")
            gr.Markdown("Masukkan ID data yang akan dihapus (pisahkan dengan koma)")
            bulk_delete_ids = gr.Textbox(
                label="ID Data (contoh: 1,2,3)",
                placeholder="Masukkan ID data yang akan dihapus"
            )
            with gr.Row():
                konfirmasi_bulk_delete = gr.Button("🗑️ Konfirmasi Bulk Delete", variant="stop", size="sm")
                batal_bulk_delete = gr.Button("❌ Batal", size="sm")

        df_count = fetch_table()
        jml_data = len(df_count) if hasattr(df_count, '__len__') else 0
        # gr.Markdown(f"### Data Masyarakat ({jml_data} data) - Mulai ulang server jika data tidak berubah")
        gr.Markdown(f"### Data Masyarakat - Mulai ulang server jika data tidak berubah")
        data_table = gr.DataFrame(
            df_count,
            interactive=False,
            label=None,
            elem_id="data_masyarakat",
            wrap=True
        )

        # Remove perhitungan_btn, modal_perhitungan, and related handlers
        # (All code related to perhitungan_btn, modal_perhitungan, show_modal_perhitungan, hide_modal_perhitungan, close_perhitungan)
        # No perhitungan button or modal in this view anymore

        kepala_section = gr.Group(visible=False)
        # HAPUS seluruh isi kepala_section (validasi prediksi dan manajemen user)

        # Definisikan tombol hapus_semua_btn sebelum update_button_visibility
        # hapus_semua_btn = gr.Button("Hapus Semua Data", variant="stop", visible=False) # Moved outside

        # Functions
        def search_data(search_term):
            if not search_term or search_term.strip() == "":
                return fetch_table()
            try:
                df = database.search_masyarakat(search_term.strip())
                if df.empty:
                    return pd.DataFrame(columns=['id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'kategori'])
                return df
            except Exception:
                return fetch_table()

        def update_button_visibility():
            role = get_user_role(user_state)
            show = role in ["pegawai", "kepala"]
            is_kepala = role == "kepala"
            return (
                gr.update(visible=show),      # tambah_btn
                gr.update(visible=show),      # edit_btn
                gr.update(visible=show),      # hapus_btn
                gr.update(visible=show),      # bulk_delete_btn
                gr.update(visible=show),      # import_btn
                gr.update(visible=show),      # hapus_semua_btn
                # gr.update(visible=show),   # export_btn (hapus)
                gr.update(visible=not show),  # login_message
                gr.update(visible=is_kepala), # kepala_section
                # gr.update(visible=show),      # perhitungan_btn
                # gr.update(visible=show),      # hapus_semua_btn (moved)
            )
        refresh_visibility_btn.click(fn=update_button_visibility, outputs=[
            tambah_btn, edit_btn, hapus_btn, bulk_delete_btn,
            import_btn, hapus_semua_btn, login_message, kepala_section,
            # hapus_semua_btn # Moved
        ])

        def clear_search():
            return "", fetch_table()

        def refresh_table():
            return fetch_table()

        def show_modal_tambah():
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False), # modal_tambah
                    gr.update(visible=False), # modal_edit
                    gr.update(visible=False), # modal_hapus
                    gr.update(visible=False)  # modal_bulk_delete
                )
            return (
                gr.update(visible=False), # status_box
                gr.update(visible=True),  # modal_tambah
                gr.update(visible=False), # modal_edit
                gr.update(visible=False), # modal_hapus
                gr.update(visible=False)  # modal_bulk_delete
            )

        def hide_modal_tambah():
            return gr.update(visible=False)
        def hide_modal_edit():
            return gr.update(visible=False)

        def tambah_data(nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori):
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False),
                    "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat",
                    fetch_table()
                )
            if not nama or not nama.strip():
                return (
                    gr.update(visible=True, value="❌ **Nama harus diisi!**"),
                    gr.update(visible=False),
                    "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat",
                    fetch_table()
                )
            try:
                ibu_hamil_val = 2 if ibu_hamil == "Ya" else 1
                disabilitas_val = 2 if disabilitas == "Ya" else 1
                lansia_val = 2 if lansia == "Ya" else 1
                success = database.insert_masyarakat(
                    nama.strip(),
                    pekerjaan_ayah,
                    jumlah_anak,
                    ibu_hamil_val,
                    disabilitas_val,
                    lansia_val,
                    kategori
                )
                if success:
                    return (
                        gr.update(visible=True, value="✅ **Data berhasil ditambahkan!**"),
                        gr.update(visible=False),
                        "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat",
                        fetch_table()
                    )
                else:
                    return (
                        gr.update(visible=True, value="❌ **Gagal menambahkan data!**"),
                        gr.update(visible=False),
                        "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat",
                        fetch_table()
                    )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error:** {str(e)}"),
                    gr.update(visible=False),
                    "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat",
                    fetch_table()
                )

        def show_modal_edit():
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False), # modal_tambah
                    gr.update(visible=False), # modal_edit
                    gr.update(visible=False), # modal_hapus
                    gr.update(visible=False), # modal_bulk_delete
                    gr.update(choices=[]) # edit_id
                )
            try:
                df = database.fetch_all_masyarakat()
                if not df.empty:
                    choices = [f"id: {row['id']}, nama: {row['nama']}" for _, row in df.iterrows()]
                    return (
                        gr.update(visible=False), # status_box
                        gr.update(visible=False), # modal_tambah
                        gr.update(visible=True),  # modal_edit
                        gr.update(visible=False), # modal_hapus
                        gr.update(visible=False), # modal_bulk_delete
                        gr.update(choices=choices) # edit_id
                    )
                else:
                    return (
                        gr.update(visible=True, value="❌ **Tidak ada data untuk diedit**"),
                        gr.update(visible=False), # modal_tambah
                        gr.update(visible=False), # modal_edit
                        gr.update(visible=False), # modal_hapus
                        gr.update(visible=False), # modal_bulk_delete
                        gr.update(choices=[]) # edit_id
                    )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error:** {str(e)}"),
                    gr.update(visible=False), # modal_tambah
                    gr.update(visible=False), # modal_edit
                    gr.update(visible=False), # modal_hapus
                    gr.update(visible=False), # modal_bulk_delete
                    gr.update(choices=[]) # edit_id
                )

        def load_data_edit(selected_id):
            try:
                if not selected_id:
                    return "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat"
                # Ambil id numerik
                if isinstance(selected_id, str) and selected_id.startswith("id:"):
                    id_num = int(selected_id.split(",")[0].replace("id:", "").strip())
                else:
                    id_num = selected_id
                data = database.get_masyarakat_by_id(id_num)
                if data:
                    return (
                        data['nama'],
                        data['pekerjaan_ayah'],
                        data['jumlah_anak'],
                        map_ibu_hamil(data['ibu_hamil']),
                        map_disabilitas(data['disabilitas']),
                        map_lansia(data['lansia']),
                        data.get('kategori', data.get('Kategori', "Tidak Dapat"))
                    )
                return "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat"
            except Exception:
                return "", "Tidak Bekerja", 0, "Tidak", "Tidak", "Tidak", "Tidak Dapat"

        def edit_data(edit_id, nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori):
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False),
                    fetch_table()
                )
            try:
                id_num = extract_id(edit_id)
                ibu_hamil_val = 2 if ibu_hamil == "Ya" else 1
                disabilitas_val = 2 if disabilitas == "Ya" else 1
                lansia_val = 2 if lansia == "Ya" else 1
                success = database.update_masyarakat(
                    id_num,
                    nama.strip(),
                    pekerjaan_ayah,
                    jumlah_anak,
                    ibu_hamil_val,
                    disabilitas_val,
                    lansia_val,
                    kategori
                )
                if success:
                    return (
                        gr.update(visible=True, value="✅ **Data berhasil diperbarui!**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
                else:
                    return (
                        gr.update(visible=True, value="❌ **Gagal memperbarui data!**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error:** {str(e)}"),
                    gr.update(visible=False),
                    fetch_table()
                )

        def show_modal_hapus():
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False), # modal_tambah
                    gr.update(visible=False), # modal_edit
                    gr.update(visible=False), # modal_hapus
                    gr.update(visible=False), # modal_bulk_delete
                    gr.update(choices=[]) # hapus_id
                )
            try:
                df = database.fetch_all_masyarakat()
                if not df.empty:
                    choices = [f"id: {row['id']}, nama: {row['nama']}" for _, row in df.iterrows()]
                    return (
                        gr.update(visible=False), # status_box
                        gr.update(visible=False), # modal_tambah
                        gr.update(visible=False), # modal_edit
                        gr.update(visible=True),  # modal_hapus
                        gr.update(visible=False), # modal_bulk_delete
                        gr.update(choices=choices) # hapus_id
                    )
                else:
                    return (
                        gr.update(visible=True, value="❌ **Tidak ada data untuk dihapus**"),
                        gr.update(visible=False), # modal_tambah
                        gr.update(visible=False), # modal_edit
                        gr.update(visible=False), # modal_hapus
                        gr.update(visible=False), # modal_bulk_delete
                        gr.update(choices=[]) # hapus_id
                    )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error:** {str(e)}"),
                    gr.update(visible=False), # modal_tambah
                    gr.update(visible=False), # modal_edit
                    gr.update(visible=False), # modal_hapus
                    gr.update(visible=False), # modal_bulk_delete
                    gr.update(choices=[]) # hapus_id
                )

        def hide_modal_hapus():
            return gr.update(visible=False)

        def hapus_data(hapus_id):
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False),
                    fetch_table()
                )
            try:
                id_num = extract_id(hapus_id)
                success = database.delete_masyarakat(id_num)
                if success:
                    return (
                        gr.update(visible=True, value="✅ **Data berhasil dihapus!**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
                else:
                    return (
                        gr.update(visible=True, value="❌ **Gagal menghapus data!**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error:** {str(e)}"),
                    gr.update(visible=False),
                    fetch_table()
                )

        def show_modal_bulk_delete():
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False), # modal_tambah
                    gr.update(visible=False), # modal_edit
                    gr.update(visible=False), # modal_hapus
                    gr.update(visible=False)  # modal_bulk_delete
                )
            return (
                gr.update(visible=False), # status_box
                gr.update(visible=False), # modal_tambah
                gr.update(visible=False), # modal_edit
                gr.update(visible=False), # modal_hapus
                gr.update(visible=True)   # modal_bulk_delete
            )

        def hide_modal_bulk_delete():
            return gr.update(visible=False)

        def bulk_delete_data(bulk_delete_ids):
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    gr.update(visible=False),
                    fetch_table()
                )
            try:
                ids_to_delete = [int(id.strip()) for id in bulk_delete_ids.split(',') if id.strip()]
                if not ids_to_delete:
                    return (
                        gr.update(visible=True, value="❌ **Tidak ada ID yang dipilih untuk dihapus!**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
                success_count = 0
                for id in ids_to_delete:
                    if database.delete_masyarakat(id):
                        success_count += 1
                    else:
                        # Optionally, log failed deletions
                        pass
                if success_count == len(ids_to_delete):
                    return (
                        gr.update(visible=True, value=f"✅ **{success_count} data berhasil dihapus!**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
                else:
                    return (
                        gr.update(visible=True, value=f"❌ **Gagal menghapus {len(ids_to_delete) - success_count} data. Berhasil menghapus {success_count} data.**"),
                        gr.update(visible=False),
                        fetch_table()
                    )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error:** {str(e)}"),
                    gr.update(visible=False),
                    fetch_table()
                )

        def import_csv(import_file):
            role = get_user_role(user_state)
            if role == "unauthorized" or role == "masyarakat":
                return (
                    gr.update(visible=True, value="❌ **Akses ditolak!** Silakan login terlebih dahulu."),
                    fetch_table()
                )
            if not import_file:
                return (
                    gr.update(visible=True, value="❌ **Pilih file CSV untuk diimpor!**"),
                    fetch_table()
                )
            try:
                df = pd.read_csv(import_file.name)
                if df.empty:
                    return (
                        gr.update(visible=True, value="❌ **File CSV kosong atau tidak berisi data!**"),
                        fetch_table()
                    )
                # Mapping kolom CSV ke database
                df['ibu_hamil'] = df['ibu_hamil'].apply(lambda x: 2 if x == "Ya" else 1)
                df['disabilitas'] = df['disabilitas'].apply(lambda x: 2 if x == "Ya" else 1)
                df['lansia'] = df['lansia'].apply(lambda x: 2 if x == "Ya" else 1)
                df['kategori'] = df['kategori'].apply(lambda x: "Dapat" if x == "Dapat" else "Tidak Dapat")

                # Validasi data
                for index, row in df.iterrows():
                    if not row['nama'] or not row['nama'].strip():
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Nama tidak boleh kosong!**"),
                            fetch_table()
                        )
                    if not row['pekerjaan_ayah'] or not row['pekerjaan_ayah'].strip():
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Pekerjaan Ayah tidak boleh kosong!**"),
                            fetch_table()
                        )
                    if row['jumlah_anak'] is None or row['jumlah_anak'] < 0:
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Jumlah Anak tidak boleh negatif!**"),
                            fetch_table()
                        )
                    if row['ibu_hamil'] not in [1, 2]:
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Ibu Hamil harus 1 (Tidak) atau 2 (Ya)!**"),
                            fetch_table()
                        )
                    if row['disabilitas'] not in [1, 2]:
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Disabilitas harus 1 (Tidak) atau 2 (Ya)!**"),
                            fetch_table()
                        )
                    if row['lansia'] not in [1, 2]:
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Lansia harus 1 (Tidak) atau 2 (Ya)!**"),
                            fetch_table()
                        )
                    if row['kategori'] not in ["Tidak Dapat", "Dapat"]:
                        return (
                            gr.update(visible=True, value=f"❌ **Gagal mengimpor data ke-{(index + 1)}: Kategori harus 'Tidak Dapat' atau 'Dapat'!**"),
                        fetch_table()
                    )
                
                # Insert data ke database
                success_count = 0
                for index, row in df.iterrows():
                    try:
                        success = database.insert_masyarakat(
                            row['nama'].strip(),
                            row['pekerjaan_ayah'].strip(),
                            row['jumlah_anak'],
                            row['ibu_hamil'],
                            row['disabilitas'],
                            row['lansia'],
                            row['kategori']
                        )
                        if success:
                            success_count += 1
                        else:
                            # Optionally, log failed insertions
                            pass
                    except Exception as e:
                        # Optionally, log failed insertions
                        pass

                if success_count == len(df):
                    return (
                        gr.update(visible=True, value=f"✅ **{success_count} data berhasil diimpor!**"),
                        fetch_table()
                    )
                else:
                    return (
                        gr.update(visible=True, value=f"❌ **Gagal mengimpor {len(df) - success_count} data. Berhasil mengimpor {success_count} data.**"),
                    fetch_table()
                )
            except Exception as e:
                return (
                    gr.update(visible=True, value=f"❌ **Error saat mengimpor file CSV:** {str(e)}"),
                    fetch_table()
                )

        # Handler hapus semua data langsung eksekusi tanpa konfirmasi
        def hapus_semua_data():
            try:
                database.hapus_semua_masyarakat()
                return gr.update(visible=True, value="✅ **Semua data masyarakat berhasil dihapus!**"), fetch_table()
            except Exception as e:
                return gr.update(visible=True, value=f"❌ **Gagal menghapus semua data: {str(e)}"), fetch_table()
        hapus_semua_btn.click(fn=hapus_semua_data, outputs=[status_box, data_table])
        # Hilangkan tombol OK/Batal konfirmasi

        # Event handlers
        search_btn.click(fn=search_data, inputs=[search_box], outputs=[data_table])
        clear_search_btn.click(fn=clear_search, outputs=[search_box, data_table])
        refresh_data_btn.click(fn=refresh_table, outputs=[data_table])
        # refresh_btn.click(fn=refresh_table, outputs=[data_table])
        
        # Modal handlers
        tambah_btn.click(fn=show_modal_tambah, outputs=[status_box, modal_tambah, modal_edit, modal_hapus, modal_bulk_delete])
        batal_tambah.click(fn=hide_modal_tambah, outputs=[modal_tambah])
        simpan_tambah.click(
            fn=tambah_data,
            inputs=[tambah_nama, tambah_pekerjaan_ayah, tambah_jumlah_anak, tambah_ibu_hamil, tambah_disabilitas, tambah_lansia,tambah_kategori],
            outputs=[status_box, modal_tambah, tambah_nama, tambah_pekerjaan_ayah, tambah_jumlah_anak, tambah_ibu_hamil, tambah_disabilitas, tambah_lansia,tambah_kategori, data_table]
        )
        
        edit_btn.click(fn=show_modal_edit, outputs=[status_box, modal_tambah, modal_edit, modal_hapus, modal_bulk_delete, edit_id])
        edit_id.change(
            fn=load_data_edit,
            inputs=[edit_id],
            outputs=[
                edit_nama,
                edit_pekerjaan_ayah,
                edit_jumlah_anak,
                edit_ibu_hamil,
                edit_disabilitas,
                edit_lansia,
                edit_kategori
            ]
        )
        simpan_edit.click(
            fn=edit_data,
            inputs=[edit_id, edit_nama, edit_pekerjaan_ayah, edit_jumlah_anak, edit_ibu_hamil, edit_disabilitas, edit_lansia, edit_kategori],
            outputs=[status_box, modal_edit, data_table]
        )
        batal_edit.click(fn=hide_modal_edit, outputs=[modal_edit])
        
        hapus_btn.click(fn=show_modal_hapus, outputs=[status_box, modal_tambah, modal_edit, modal_hapus, modal_bulk_delete, hapus_id])
        batal_hapus.click(fn=hide_modal_hapus, outputs=[modal_hapus])
        konfirmasi_hapus.click(fn=hapus_data, inputs=[hapus_id], outputs=[status_box, modal_hapus, data_table])
        
        bulk_delete_btn.click(fn=show_modal_bulk_delete, outputs=[status_box, modal_tambah, modal_edit, modal_hapus, modal_bulk_delete])
        batal_bulk_delete.click(fn=hide_modal_bulk_delete, outputs=[modal_bulk_delete])
        konfirmasi_bulk_delete.click(fn=bulk_delete_data, inputs=[bulk_delete_ids], outputs=[status_box, modal_bulk_delete, data_table])
        
        import_btn.upload(fn=import_csv, inputs=[import_btn], outputs=[status_box, data_table])
        # export_btn.click(fn=export_csv, outputs=[status_box, download_file]) # Hapus