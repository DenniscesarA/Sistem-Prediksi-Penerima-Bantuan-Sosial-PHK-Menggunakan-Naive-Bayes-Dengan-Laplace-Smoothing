import gradio as gr
from lib import database
from lib.auth import get_user_role
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
import tempfile
import os
import openpyxl

def riwayat_view(user_state):
    # Debug: show current role
    role = get_user_role(user_state)
    
    def fetch_riwayat():
        # Selalu ambil data riwayat yang sudah disetujui kepala (untuk semua user)
        try:
            df = database.fetch_validated_prediksi()
            
            # Konversi nilai angka menjadi "Tidak" dan "Ya" untuk tampilan
            def convert_to_yes_no(val):
                if pd.isna(val) or val == '':
                    return ''
                try:
                    val_int = int(val)
                    return "Ya" if val_int == 1 else "Tidak"
                except:
                    return str(val)
            
            # Terapkan konversi untuk kolom ibu_hamil, disabilitas, dan lansia
            if 'ibu_hamil' in df.columns:
                df['ibu_hamil'] = df['ibu_hamil'].apply(convert_to_yes_no)
            if 'disabilitas' in df.columns:
                df['disabilitas'] = df['disabilitas'].apply(convert_to_yes_no)
            if 'lansia' in df.columns:
                df['lansia'] = df['lansia'].apply(convert_to_yes_no)
            
            # Tambahkan kolom status_approval dengan label yang lebih jelas
            def label_status(s):
                if s == 'valid':
                    return 'Disetujui Kepala'
                elif s == 'pending':
                    return 'Menunggu Persetujuan'
                else:
                    return s.capitalize()
            df['status_approval'] = df['status'].apply(label_status)
            # Kolom Status Aktual (dari label_aktual)
            if 'label_aktual' in df.columns:
                df['status_aktual'] = df['label_aktual']
            else:
                df['status_aktual'] = ''
            # Kolom Status Prediksi (parsing dari hasil)
            def parse_status_prediksi(hasil):
                if isinstance(hasil, str) and 'Status:' in hasil:
                    val = hasil.split('Status:')[-1].strip()
                    if val.lower().startswith('dapat'):
                        return 'Dapat'
                    return 'Tidak dapat'
                return ''
            df['status_prediksi'] = df['hasil'].apply(parse_status_prediksi)
            # Kolom Probabilitas P(Dapat|X) dan P(Tidak Dapat|X)
            def parse_p_dapat(hasil):
                if isinstance(hasil, str) and 'P(Dapat):' in hasil:
                    try:
                        return hasil.split('P(Dapat):')[1].split(',')[0].strip()
                    except Exception:
                        return ''
                return ''
            def parse_p_tidak(hasil):
                if isinstance(hasil, str) and 'P(Tidak Dapat):' in hasil:
                    try:
                        return hasil.split('P(Tidak Dapat):')[1].split(',')[0].strip()
                    except Exception:
                        return ''
                return ''
            df['p_dapat'] = df['hasil'].apply(parse_p_dapat)
            df['p_tidak'] = df['hasil'].apply(parse_p_tidak)
            # Urutkan kolom agar hanya kolom data, status aktual, probabilitas, dan status prediksi yang tampil (tanpa status dan status_approval)
            cols = ['id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'created_at', 'status_aktual', 'p_dapat', 'p_tidak', 'status_prediksi']
            df = df[[c for c in cols if c in df.columns]]
            return df
        except Exception as e:
            print(f"Error fetching riwayat: {e}")
            return pd.DataFrame(columns=['id', 'nama', 'pekerjaan_ayah', 'jumlah_anak', 'ibu_hamil', 'disabilitas', 'lansia', 'status_aktual', 'status_prediksi', 'hasil', 'status', 'status_approval'])

    with gr.Column():
        
        gr.Markdown("# 📋 Riwayat Prediksi")
        
        # Show role info
        role_info = gr.Markdown(f"**Role saat ini:** {role}")
        
        # Status box - pindahkan ke luar blok if agar selalu tersedia
        status_box = gr.Textbox(label="Status Operasi", interactive=False, visible=False)
        
        # Dynamic count display
        def get_riwayat_count():
            try:
                df = database.fetch_validated_prediksi()
                return f"Berikut adalah riwayat prediksi kelayakan bantuan PKH yang sudah disetujui kepala: **({len(df)} data)**"
            except Exception:
                return "Berikut adalah riwayat prediksi kelayakan bantuan PKH yang sudah disetujui kepala: **(0 data)**"
        
        riwayat_count_md = gr.Markdown(get_riwayat_count())
        
        # Combined refresh button - selalu tampilkan untuk semua user
        with gr.Row():
            refresh_btn = gr.Button("🔄 Refresh Data", size="sm")
        
        # Data table - selalu tampilkan untuk semua user
        riwayat_table = gr.DataFrame(
            fetch_riwayat(),
            label="Riwayat Prediksi",
            interactive=False,
            wrap=True
        )
        
        # Tombol hapus & hapus semua (hanya untuk user yang sudah login)
        with gr.Row():
            hapus_btn = gr.Button("🗑️ Hapus", variant="stop", size="sm", visible=False)
            hapus_semua_btn = gr.Button("💀 Hapus Semua", variant="stop", size="sm", visible=False)

        # Modal hapus satu
        with gr.Group(visible=False) as modal_hapus:
            gr.Markdown("## 🗑️ Hapus Riwayat Prediksi")
            hapus_id = gr.Dropdown(choices=[], label="Pilih ID Prediksi untuk Dihapus", interactive=True)
            with gr.Row():
                konfirmasi_hapus = gr.Button("🗑️ Konfirmasi Hapus", variant="stop", size="sm")
                batal_hapus = gr.Button("❌ Batal", size="sm")

        # Komponen chart dan download - selalu ada tapi visibility dikontrol
        with gr.Column():
            tampilkan_chart_btn = gr.Button("Tampilkan Chart Rekap Bulanan", variant="primary", visible=False)
            chart_html = gr.HTML()
            download_btn = gr.Button("Download Data Riwayat (Excel)", visible=False)
            download_status = gr.Textbox(label="Status Download Excel", interactive=False)
            download_file = gr.File(label="Download Data Riwayat Excel", visible=False)
        
        # Pesan untuk user yang belum login
        login_message = gr.Markdown("🔒 **Silakan login terlebih dahulu untuk mengakses fitur chart dan download Excel**", visible=False)
        
        # Function untuk update visibility tombol export dan chart
        def update_export_chart_visibility():
            role = get_user_role(user_state)
            show = role != "unauthorized"
            return (
                gr.update(visible=show),      # hapus_btn
                gr.update(visible=show),      # hapus_semua_btn
                gr.update(visible=show),      # tampilkan_chart_btn
                gr.update(visible=show),      # download_btn
                gr.update(visible=not show),  # login_message
            )

        # Handler untuk refresh data dan visibility
        def refresh_riwayat_data_and_visibility():
            # Update data dan count
            df = fetch_riwayat()
            count_text = f"Berikut adalah riwayat prediksi kelayakan bantuan PKH yang sudah disetujui kepala: **({len(df)} data)**"
            
            # Update visibility
            role = get_user_role(user_state)
            show = role != "unauthorized"
            
            return (
                df,                           # riwayat_table
                count_text,                   # riwayat_count_md
                gr.update(visible=show),      # hapus_btn
                gr.update(visible=show),      # hapus_semua_btn
                gr.update(visible=show),      # tampilkan_chart_btn
                gr.update(visible=show),      # download_btn
                gr.update(visible=not show),  # login_message
            )
        
        refresh_btn.click(fn=refresh_riwayat_data_and_visibility, outputs=[
            riwayat_table, riwayat_count_md, hapus_btn, hapus_semua_btn, 
            tampilkan_chart_btn, download_btn, login_message
        ])

        # Handler hapus satu
        def show_modal_hapus():
            try:
                df = fetch_riwayat()
                if not df.empty:
                    choices = [f"id: {row['id']}, nama: {row['nama']}" for _, row in df.iterrows()]
                    return gr.update(visible=True), gr.update(choices=choices)
                else:
                    return gr.update(visible=True), gr.update(choices=[])
            except Exception:
                return gr.update(visible=True), gr.update(choices=[])
        def hide_modal_hapus():
            return gr.update(visible=False)
        def extract_id(selected_value):
            if selected_value and selected_value.startswith("id:"):
                return int(selected_value.split(",")[0].replace("id:", "").strip())
            return None
        def hapus_riwayat(hapus_id):
            try:
                id_num = extract_id(hapus_id)
                if id_num is None:
                    return gr.update(visible=True, value="❌ **ID tidak valid!**"), gr.update(visible=False), fetch_riwayat(), get_riwayat_count()
                success = database.delete_prediksi(id_num)
                if success:
                    return gr.update(visible=True, value="✅ **Riwayat prediksi berhasil dihapus!**"), gr.update(visible=False), fetch_riwayat(), get_riwayat_count()
                else:
                    return gr.update(visible=True, value="❌ **Gagal menghapus riwayat prediksi!**"), gr.update(visible=False), fetch_riwayat(), get_riwayat_count()
            except Exception as e:
                return gr.update(visible=True, value=f"❌ **Error:** {str(e)}"), gr.update(visible=False), fetch_riwayat(), get_riwayat_count()
        hapus_btn.click(fn=show_modal_hapus, outputs=[modal_hapus, hapus_id])
        batal_hapus.click(fn=hide_modal_hapus, outputs=[modal_hapus])
        konfirmasi_hapus.click(fn=hapus_riwayat, inputs=[hapus_id], outputs=[status_box, modal_hapus, riwayat_table, riwayat_count_md])

        # Handler hapus semua
        def hapus_semua_riwayat():
            try:
                database.hapus_semua_prediksi()
                return gr.update(visible=True, value="✅ **Semua riwayat prediksi berhasil dihapus!**"), fetch_riwayat(), get_riwayat_count()
            except Exception as e:
                return gr.update(visible=True, value=f"❌ **Gagal menghapus semua riwayat: {str(e)}"), fetch_riwayat(), get_riwayat_count()
        hapus_semua_btn.click(fn=hapus_semua_riwayat, outputs=[status_box, riwayat_table, riwayat_count_md]) 

        # Rekap bulanan
        def rekap_bulanan():
            df = fetch_riwayat()
            if 'created_at' not in df.columns or df.empty:
                return None, None
            # Buat copy DataFrame untuk menghindari warning
            df_copy = df.copy()
            df_copy['created_at'] = pd.to_datetime(df_copy['created_at'], errors='coerce')
            df_copy = df_copy.dropna(subset=['created_at'])
            df_copy['bulan'] = df_copy['created_at'].dt.to_period('M').astype(str)
            rekap = df_copy.groupby('bulan').size().reset_index(name='jumlah_prediksi')
            # Chart
            plt.figure(figsize=(8,4))
            plt.bar(rekap['bulan'], rekap['jumlah_prediksi'], color='skyblue')
            plt.xlabel('Bulan')
            plt.ylabel('Jumlah Prediksi')
            plt.title('Rekap Jumlah Prediksi per Bulan')
            plt.xticks(rotation=45)
            buf = io.BytesIO()
            plt.tight_layout()
            plt.savefig(buf, format='png')
            buf.seek(0)
            img_str = base64.b64encode(buf.getvalue()).decode()
            plt.close()
            # Excel
            excel_buf = io.BytesIO()
            rekap.to_excel(excel_buf, index=False)
            excel_buf.seek(0)
            return img_str, excel_buf

        def tampilkan_chart_dan_excel():
            img_str, excel_buf = rekap_bulanan()
            if img_str is None:
                return gr.update(value="<i>Data tidak tersedia untuk rekap bulanan.</i>")
            html = f"<h4>Rekap Jumlah Prediksi per Bulan</h4><img src='data:image/png;base64,{img_str}' style='max-width: 100%;'>"
            return gr.update(value=html)

        def download_riwayat_excel():
            """Download data riwayat lengkap dengan tanggal prediksi"""
            try:
                # Ambil data asli dari database (tanpa konversi untuk download)
                df_original = database.fetch_validated_prediksi()
                if df_original.empty:
                    return gr.update(visible=False), "❌ Tidak ada data riwayat untuk diunduh."
                
                # Konversi nilai angka menjadi "Tidak" dan "Ya" untuk download
                def convert_to_yes_no(val):
                    if pd.isna(val) or val == '':
                        return ''
                    try:
                        val_int = int(val)
                        return "Ya" if val_int == 1 else "Tidak"
                    except:
                        return str(val)
                
                # Terapkan konversi untuk kolom ibu_hamil, disabilitas, dan lansia
                df_copy = df_original.copy()
                if 'ibu_hamil' in df_copy.columns:
                    df_copy['ibu_hamil'] = df_copy['ibu_hamil'].apply(convert_to_yes_no)
                if 'disabilitas' in df_copy.columns:
                    df_copy['disabilitas'] = df_copy['disabilitas'].apply(convert_to_yes_no)
                if 'lansia' in df_copy.columns:
                    df_copy['lansia'] = df_copy['lansia'].apply(convert_to_yes_no)
                
                # Pastikan kolom created_at ada dan format yang benar
                if 'created_at' in df_copy.columns:
                    # Format tanggal untuk tampilan yang lebih baik
                    df_copy['Tanggal Prediksi'] = pd.to_datetime(df_copy['created_at']).dt.strftime('%d/%m/%Y %H:%M:%S')
                else:
                    df_copy['Tanggal Prediksi'] = 'Tidak tersedia'
                
                # Tambahkan kolom yang diperlukan untuk download
                # Kolom Status Aktual (dari label_aktual)
                if 'label_aktual' in df_copy.columns:
                    df_copy['status_aktual'] = df_copy['label_aktual']
                else:
                    df_copy['status_aktual'] = ''
                # Kolom Status Prediksi (parsing dari hasil)
                def parse_status_prediksi(hasil):
                    if isinstance(hasil, str) and 'Status:' in hasil:
                        return hasil.split('Status:')[-1].strip()
                    return ''
                df_copy['status_prediksi'] = df_copy['hasil'].apply(parse_status_prediksi)
                # Kolom Probabilitas P(Dapat|X) dan P(Tidak Dapat|X)
                def parse_p_dapat(hasil):
                    if isinstance(hasil, str) and 'P(Dapat):' in hasil:
                        try:
                            return hasil.split('P(Dapat):')[1].split(',')[0].strip()
                        except:
                            return ''
                    return ''
                def parse_p_tidak(hasil):
                    if isinstance(hasil, str) and 'P(Tidak Dapat):' in hasil:
                        try:
                            return hasil.split('P(Tidak Dapat):')[1].split(',')[0].strip()
                        except:
                            return ''
                    return ''
                df_copy['p_dapat'] = df_copy['hasil'].apply(parse_p_dapat)
                df_copy['p_tidak'] = df_copy['hasil'].apply(parse_p_tidak)
                
                # Rename kolom untuk tampilan yang lebih baik
                column_mapping = {
                    'id': 'ID',
                    'nama': 'Nama',
                    'pekerjaan_ayah': 'Pekerjaan Ayah',
                    'jumlah_anak': 'Jumlah Anak',
                    'ibu_hamil': 'Ibu Hamil',
                    'disabilitas': 'Disabilitas',
                    'lansia': 'Lansia',
                    'status_aktual': 'Status Aktual',
                    'p_dapat': 'Probabilitas Dapat',
                    'p_tidak': 'Probabilitas Tidak Dapat',
                    'status_prediksi': 'Status Prediksi'
                }
                
                # Pilih dan rename kolom yang akan diekspor
                export_columns = ['ID', 'Tanggal Prediksi', 'Nama', 'Pekerjaan Ayah', 'Jumlah Anak', 'Ibu Hamil', 
                                'Disabilitas', 'Lansia', 'Status Aktual', 
                                'Probabilitas Dapat', 'Probabilitas Tidak Dapat', 'Status Prediksi']
                
                # Rename kolom yang ada
                for old_col, new_col in column_mapping.items():
                    if old_col in df_copy.columns:
                        df_copy = df_copy.rename(columns={old_col: new_col})
                
                # Pilih hanya kolom yang akan diekspor
                df_export = df_copy[[col for col in export_columns if col in df_copy.columns]]
                
                # Buat file Excel
                excel_buf = io.BytesIO()
                with pd.ExcelWriter(excel_buf, engine='openpyxl') as writer:
                    df_export.to_excel(writer, sheet_name='Riwayat Prediksi', index=False)
                    
                    # Auto-adjust column widths
                    worksheet = writer.sheets['Riwayat Prediksi']
                    for column in worksheet.columns:
                        max_length = 0
                        column_letter = column[0].column_letter
                        for cell in column:
                            try:
                                if len(str(cell.value)) > max_length:
                                    max_length = len(str(cell.value))
                            except:
                                pass
                        adjusted_width = min(max_length + 2, 50)
                        worksheet.column_dimensions[column_letter].width = adjusted_width
                
                excel_buf.seek(0)
                
                # Buat file temporary dengan nama yang informatif
                timestamp = pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')
                filename = f"riwayat_prediksi_pkh_{timestamp}.xlsx"
                with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                    tmp.write(excel_buf.read())
                    tmp_path = tmp.name
                
                status_msg = f"✅ **Excel berhasil dibuat!** Silakan klik tombol angka (contoh. 85KB) di samping bawah untuk mengunduh data riwayat prediksi PKH."
                return gr.update(value=tmp_path, visible=True), status_msg
                
            except Exception as e:
                return gr.update(visible=False), f"❌ **Error generating Excel:** {str(e)}"

        # Tombol untuk menampilkan chart
        tampilkan_chart_btn.click(
            fn=tampilkan_chart_dan_excel,
            outputs=[chart_html]
        )
        # Tombol download data riwayat lengkap
        download_btn.click(
            fn=download_riwayat_excel,
            outputs=[download_file, download_status]
        ) 