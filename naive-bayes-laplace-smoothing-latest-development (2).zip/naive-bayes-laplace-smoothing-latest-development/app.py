import gradio as gr
from lib.auth import get_user_role, load_session, save_session, clear_session
from views.beranda import beranda_view
from views.kelola_data import kelola_data_view
from views.prediksi import prediksi_view
from views.riwayat import riwayat_view
from views.evaluasi import evaluasi_view
from views.login import create_login_components
from views.perhitungan import perhitungan_metode_view
from lib import database
import json
import datetime
import os

# State: user info & role
user_state = gr.State({"role": "unauthorized", "username": None})

# Global variable untuk tracking login state
current_user_role = "unauthorized"
current_username = None

def main_app():
    with gr.Blocks(css="""
        .error-message {
            background-color: #fee;
            border: 2px solid #fcc;
            border-radius: 8px;
            padding: 12px;
            margin: 10px 0;
            color: #c33;
            font-weight: bold;
        }
        .success-message {
            background-color: #efe;
            border: 2px solid #cfc;
            border-radius: 8px;
            padding: 12px;
            margin: 10px 0;
            color: #363;
            font-weight: bold;
        }
    """) as app:
        
        # Fungsi untuk refresh seluruh aplikasi
        def refresh_app():
            return gr.Blocks.update()
        # Header dengan judul dan status login
        with gr.Row():
            with gr.Column(scale=3):
                gr.Markdown("# Aplikasi Prediksi Kelayakan Bantuan PKH", elem_id="main-title")
            with gr.Column(scale=1):
                login_status = gr.Markdown("", elem_id="login-status")
                logout_btn = gr.Button("Logout", variant="secondary", size="sm", visible=False, elem_id="logout-btn")

        def get_tabs_by_role(role):
            tabs = []
            # Beranda selalu ada
            tabs.append(("Beranda", lambda: gr.Markdown(beranda_view(user_state))))
            tabs.append(("Kelola Data", lambda: kelola_data_view(user_state)))
            
            # Menu Perhitungan Metode - selalu ada tapi visibility dikontrol
            tabs.append(("Perhitungan Metode", lambda: perhitungan_metode_view(user_state)))
            
            tabs.append(("Prediksi", lambda: prediksi_view(user_state)))
            tabs.append(("Riwayat", lambda: riwayat_view(user_state)))
            
            # Menu Evaluasi - selalu ada tapi visibility dikontrol
            tabs.append(("Evaluasi", lambda: evaluasi_view(user_state)))
            
            # Login tab selalu ada
            tabs.append(("Login", None))
            return tabs

        def render_tabs():
            role = get_user_role(user_state)
            tabs = get_tabs_by_role(role)
            with gr.Tabs() as main_tabs:
                tab_refs = {}
                login_components = None
                
                # Fungsi untuk refresh tabs berdasarkan role
                def refresh_tabs():
                    return gr.Tabs.update(selected=0)  # Kembali ke tab pertama
                
                for tab_name, tab_func in tabs:
                    if tab_name == "Login":
                        # Login tab visibility berdasarkan role
                        login_visible = role == "unauthorized"
                        with gr.TabItem(tab_name, visible=login_visible) as login_tab:
                            login_components = create_login_components(user_state)
                            login_components['login_container']
                            tab_refs[tab_name] = login_tab
                            
                            # Bind login event handler
                            login_components['login_btn'].click(
                                fn=login_components['handle_login'],
                                inputs=[login_components['username'], login_components['password']],
                                outputs=[login_components['login_error'], login_tab, login_status, logout_btn, tab_refs.get('Perhitungan Metode'), tab_refs.get('Evaluasi')]
                            )
                            
                            # Bind clear error handlers
                            login_components['username'].change(
                                fn=login_components['clear_error'],
                                outputs=[login_components['login_error']]
                            )
                            login_components['password'].change(
                                fn=login_components['clear_error'],
                                outputs=[login_components['login_error']]
                            )
                            
                            # Bind submit handlers
                            login_components['username'].submit(
                                fn=login_components['handle_login'],
                                inputs=[login_components['username'], login_components['password']],
                                outputs=[login_components['login_error'], login_tab, login_status, logout_btn, tab_refs.get('Perhitungan Metode'), tab_refs.get('Evaluasi')]
                            )
                            
                            login_components['password'].submit(
                                fn=login_components['handle_login'],
                                inputs=[login_components['username'], login_components['password']],
                                outputs=[login_components['login_error'], login_tab, login_status, logout_btn, tab_refs.get('Perhitungan Metode'), tab_refs.get('Evaluasi')]
                            )
                            
                    else:
                        # Kontrol visibility untuk Perhitungan Metode dan Evaluasi berdasarkan role
                        if tab_name == "Perhitungan Metode":
                            perhitungan_visible = role == "kepala"
                            with gr.TabItem(tab_name, visible=perhitungan_visible) as tab_ref:
                                if tab_func:
                                    tab_func()
                                tab_refs[tab_name] = tab_ref
                        elif tab_name == "Evaluasi":
                            evaluasi_visible = role == "kepala"
                            with gr.TabItem(tab_name, visible=evaluasi_visible) as tab_ref:
                                if tab_func:
                                    tab_func()
                                tab_refs[tab_name] = tab_ref
                        else:
                            with gr.TabItem(tab_name) as tab_ref:
                                if tab_func:
                                    tab_func()
                                tab_refs[tab_name] = tab_ref
                            
            # Pastikan login_components selalu ada
            if login_components is None:
                # Buat login components dummy jika tidak ada
                login_components = create_login_components(user_state)
            return tab_refs, login_components

        tab_refs, login_components = render_tabs()

        # Bind logout event handler
        logout_btn.click(
            fn=login_components['do_logout'],
            outputs=[login_status, logout_btn, tab_refs['Login'], tab_refs.get('Perhitungan Metode'), tab_refs.get('Evaluasi')]
        )
        
        # Load UI saat aplikasi dimulai
        app.load(fn=login_components['init_ui'], outputs=[login_status, logout_btn, tab_refs['Login'], tab_refs.get('Perhitungan Metode'), tab_refs.get('Evaluasi')])
        
    return app

if __name__ == "__main__":
    import socket
    def find_free_port(start_port=7860, max_attempts=10):
        for port in range(start_port, start_port + max_attempts):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('localhost', port))
                    return port
            except OSError:
                continue
        return None
    port = find_free_port()
    if port is None:
        print("Tidak bisa menemukan port yang tersedia. Coba tutup aplikasi lain yang menggunakan port 7860-7870")
        exit(1)
    print(f"Menjalankan aplikasi di port {port}")
    try:
        main_app().launch(share=True, server_port=port)
    except Exception as e:
        print(f"Tidak bisa membuat public link: {e}")
        print("Menjalankan aplikasi dalam mode local only...")
        main_app().launch(share=False, server_port=port) 