import hashlib
import json
import os
import datetime
from lib import database

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def save_session(user_data):
    """Menyimpan data user ke file session"""
    try:
        SESSION_FILE = "session.json"
        session_data = {
            "username": user_data.get("username"),
            "role": user_data.get("role"),
            "timestamp": datetime.datetime.now().isoformat()
        }
        with open(SESSION_FILE, 'w') as f:
            json.dump(session_data, f)
        return True
    except Exception as e:
        print(f"Error saving session: {e}")
        return False

def clear_session():
    """Menghapus file session"""
    try:
        SESSION_FILE = "session.json"
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)
        return True
    except Exception as e:
        print(f"Error clearing session: {e}")
        return False

def login(user_state):
    """Login user dan simpan ke state + session"""
    def do_login(username, password):
        if not username or not password:
            return "Username dan password harus diisi"
        
        # Cek autentikasi dari database
        user = database.authenticate_user(username.strip(), password)
        
        if user:
            user_state["role"] = user["role"]
            user_state["username"] = user["username"]
            
            # Simpan ke session.json
            save_session(user)
            
            return f"Login berhasil sebagai {user['role']}"
        else:
            return "Username atau password salah"
    return do_login

def load_session():
    """Memuat data user dari file session"""
    try:
        SESSION_FILE = "session.json"
        if os.path.exists(SESSION_FILE):
            with open(SESSION_FILE, 'r') as f:
                session_data = json.load(f)
            # Validasi session (misalnya timestamp atau format bisa dicek di sini)
            return session_data
    except Exception as e:
        print(f"Error loading session: {e}")
    return {"role": "unauthorized", "username": None}

def get_user_role(user_state):
    """Mengembalikan role user dari user_state, jika tidak ada maka fallback ke session file"""
    # Ambil dict dari gr.State jika perlu
    state_dict = user_state.value if hasattr(user_state, "value") else user_state
    role = state_dict.get("role", "unauthorized")
    
    # Jika role belum diset, coba baca dari session file
    if role == "unauthorized" or not role:
        session_data = load_session()
        if session_data.get("role") and session_data.get("role") != "unauthorized":
            role = session_data.get("role")
            state_dict["role"] = role
            state_dict["username"] = session_data.get("username")
    
    return role

def is_logged_in(user_state):
    """Return True jika user sudah login"""
    return get_user_role(user_state) != "unauthorized"

def create_user_account(username, password, role):
    """Membuat akun baru"""
    if not username or not password or not role:
        return False, "Semua field harus diisi"
    
    # Cek apakah username sudah ada
    existing_user = database.get_user_by_username(username.strip())
    if existing_user:
        return False, "Username sudah digunakan"
    
    # Hash password sebelum disimpan
    hashed_password = hash_password(password)
    
    # Simpan ke database
    success = database.create_user(username.strip(), hashed_password, role)
    if success:
        return True, "Akun berhasil dibuat"
    else:
        return False, "Gagal membuat akun"

def change_password(username, old_password, new_password):
    """Mengubah password user"""
    if not username or not old_password or not new_password:
        return False, "Semua field harus diisi"
    
    # Verifikasi password lama
    user = database.authenticate_user(username.strip(), old_password)
    if not user:
        return False, "Password lama salah"
    
    # Hash password baru
    hashed_new_password = hash_password(new_password)
    
    # Update password di database
    success = database.update_user_password(username.strip(), hashed_new_password)
    if success:
        return True, "Password berhasil diubah"
    else:
        return False, "Gagal mengubah password"
