import mysql.connector
from mysql.connector import Error
import pandas as pd
from sqlalchemy import create_engine, text
import warnings

# Suppress pandas warnings about SQLAlchemy
warnings.filterwarnings('ignore', category=UserWarning, module='pandas')

# Ganti parameter ini sesuai kebutuhan (bisa diubah ke DB online)
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'pkh_db',
    'port': 3306
}
def user_exists(username):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM users WHERE username = %s", (username,))
    result = cursor.fetchone()
    conn.close()
    return result is not None

    
def get_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except Error as e:
        print(f"Database connection error: {e}")
        return None

def get_sqlalchemy_engine():
    try:
        # Create SQLAlchemy engine
        connection_string = f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
        engine = create_engine(connection_string)
        
        # Test connection
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            conn.commit()
        return engine
    except Exception as e:
        print(f"SQLAlchemy engine error: {e}")
        print("Pastikan MySQL server berjalan dan database 'pkh_db' sudah dibuat")
        return None

def fetch_all_masyarakat():
    engine = get_sqlalchemy_engine()
    if not engine:
        return pd.DataFrame()
    try:
        df = pd.read_sql('SELECT * FROM masyarakat ORDER BY id DESC', engine)
        return df
    except Exception as e:
        print(f"Fetch masyarakat error: {e}")
        return pd.DataFrame()
    finally:
        engine.dispose()

def search_masyarakat(search_term):
    """Search masyarakat by name or other criteria"""
    engine = get_sqlalchemy_engine()
    if not engine:
        return pd.DataFrame()
    try:
        query = """
        SELECT * FROM masyarakat 
        WHERE nama LIKE %s OR pekerjaan_ayah LIKE %s OR kategori LIKE %s
        ORDER BY id DESC
        """
        search_pattern = f"%{search_term}%"
        df = pd.read_sql(query, engine, params=(search_pattern, search_pattern, search_pattern))
        return df
    except Exception as e:
        print(f"Search masyarakat error: {e}")
        return pd.DataFrame()
    finally:
        engine.dispose()

def get_masyarakat_by_id(id):
    """Get single masyarakat record by ID"""
    engine = get_sqlalchemy_engine()
    if not engine:
        return None
    try:
        query = "SELECT * FROM masyarakat WHERE id = %s"
        df = pd.read_sql(query, engine, params=[id])
        if not df.empty:
            return df.iloc[0].to_dict()
        return None
    except Exception as e:
        print(f"Get masyarakat by ID error: {e}")
        return None
    finally:
        engine.dispose()

def insert_masyarakat(nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = ("INSERT INTO masyarakat (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori) "
               "VALUES (%s, %s, %s, %s, %s, %s, %s)")
        cursor.execute(sql, (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori))
        conn.commit()
        return True
    except Exception as e:
        print(f"Insert error: {e}")
        return False
    finally:
        conn.close()

def update_masyarakat(id, nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = ("UPDATE masyarakat SET nama=%s, pekerjaan_ayah=%s, jumlah_anak=%s, ibu_hamil=%s, disabilitas=%s, lansia=%s, kategori=%s WHERE id=%s")
        cursor.execute(sql, (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, kategori, id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Update error: {e}")
        return False
    finally:
        conn.close()

def delete_masyarakat(id):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM masyarakat WHERE id=%s"
        cursor.execute(sql, (id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Delete error: {e}")
        return False
    finally:
        conn.close()

def hapus_semua_masyarakat():
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM masyarakat")
        conn.commit()
        return True
    except Exception as e:
        print(f"Delete all error: {e}")
        return False
    finally:
        conn.close()

def fetch_pending_prediksi():
    engine = get_sqlalchemy_engine()
    if not engine:
        return pd.DataFrame()
    try:
        df = pd.read_sql('SELECT * FROM prediksi WHERE status="pending"', engine)
        return df
    except Exception as e:
        print(f"Fetch pending prediksi error: {e}")
        return pd.DataFrame()
    finally:
        engine.dispose()

def insert_prediksi(data):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        # Cek apakah data mengandung label_aktual
        if 'label_aktual' in data:
            if 'created_at' in data:
                sql = ("INSERT INTO prediksi (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, hasil, status, label_aktual, created_at) "
                       "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)")
                cursor.execute(sql, (
                    data['nama'], data['pekerjaan_ayah'], data['jumlah_anak'],
                    data['ibu_hamil'], data['disabilitas'], data['lansia'], data['hasil'], data['status'], data['label_aktual'], data['created_at']
                ))
            else:
                sql = ("INSERT INTO prediksi (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, hasil, status, label_aktual) "
                       "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)")
                cursor.execute(sql, (
                    data['nama'], data['pekerjaan_ayah'], data['jumlah_anak'],
                    data['ibu_hamil'], data['disabilitas'], data['lansia'], data['hasil'], data['status'], data['label_aktual']
                ))
        else:
            if 'created_at' in data:
                sql = ("INSERT INTO prediksi (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, hasil, status, created_at) "
                       "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)")
                cursor.execute(sql, (
                    data['nama'], data['pekerjaan_ayah'], data['jumlah_anak'],
                    data['ibu_hamil'], data['disabilitas'], data['lansia'], data['hasil'], data['status'], data['created_at']
                ))
            else:
                sql = ("INSERT INTO prediksi (nama, pekerjaan_ayah, jumlah_anak, ibu_hamil, disabilitas, lansia, hasil, status) "
                       "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)")
                cursor.execute(sql, (
                    data['nama'], data['pekerjaan_ayah'], data['jumlah_anak'],
                    data['ibu_hamil'], data['disabilitas'], data['lansia'], data['hasil'], data['status']
                ))
        conn.commit()
        return True
    except Exception as e:
        print(f"Insert prediksi error: {e}")
        return False
    finally:
        conn.close()

def update_prediksi_status(id, status):
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "UPDATE prediksi SET status=%s WHERE id=%s"
        cursor.execute(sql, (status, id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Update prediksi status error: {e}")
        return False
    finally:
        conn.close()

def fetch_validated_prediksi():
    engine = get_sqlalchemy_engine()
    if not engine:
        return pd.DataFrame()
    try:
        df = pd.read_sql('SELECT * FROM prediksi WHERE status="valid"', engine)
        return df
    except Exception as e:
        print(f"Fetch validated prediksi error: {e}")
        return pd.DataFrame()
    finally:
        engine.dispose()

def fetch_all_prediksi():
    engine = get_sqlalchemy_engine()
    if not engine:
        return pd.DataFrame()
    try:
        df = pd.read_sql('SELECT * FROM prediksi', engine)
        return df
    except Exception as e:
        print(f"Fetch all prediksi error: {e}")
        return pd.DataFrame()
    finally:
        engine.dispose()

def delete_prediksi(id):
    """Delete single prediksi by ID"""
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM prediksi WHERE id=%s"
        cursor.execute(sql, (id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Delete prediksi error: {e}")
        return False
    finally:
        conn.close()

def hapus_semua_prediksi():
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM prediksi")
        conn.commit()
        return True
    except Exception as e:
        print(f"Delete all prediksi error: {e}")
        return False
    finally:
        conn.close()

def authenticate_user(username, password):
    """Authenticate user from database"""
    conn = get_connection()
    if not conn:
        return None
    try:
        cursor = conn.cursor(dictionary=True)
        # Cek dengan password plain text (untuk kompatibilitas dengan data existing)
        sql = "SELECT * FROM users WHERE username = %s AND password = %s"
        cursor.execute(sql, (username, password))
        user = cursor.fetchone()
        
        # Jika tidak ditemukan, coba dengan password yang di-hash
        if not user:
            import hashlib
            hashed_password = hashlib.sha256(password.encode()).hexdigest()
            cursor.execute(sql, (username, hashed_password))
            user = cursor.fetchone()
        
        return user
    except Exception as e:
        print(f"Authentication error: {e}")
        return None
    finally:
        conn.close()

def get_user_by_username(username):
    """Get user by username"""
    conn = get_connection()
    if not conn:
        return None
    try:
        cursor = conn.cursor(dictionary=True)
        sql = "SELECT * FROM users WHERE username = %s"
        cursor.execute(sql, (username,))
        user = cursor.fetchone()
        return user
    except Exception as e:
        print(f"Get user error: {e}")
        return None
    finally:
        conn.close()

def create_user(username, password, role):
    """Create new user"""
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "INSERT INTO users (username, password, role) VALUES (%s, %s, %s)"
        cursor.execute(sql, (username, password, role))
        conn.commit()
        return True
    except Exception as e:
        print(f"Create user error: {e}")
        return False
    finally:
        conn.close()

def update_user_password(username, new_password):
    """Update user password"""
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "UPDATE users SET password = %s WHERE username = %s"
        cursor.execute(sql, (new_password, username))
        conn.commit()
        return True
    except Exception as e:
        print(f"Update password error: {e}")
        return False
    finally:
        conn.close()

def update_user_info(user_id, username, role):
    """Update user username and role"""
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "UPDATE users SET username = %s, role = %s WHERE id = %s"
        cursor.execute(sql, (username, role, user_id))
        conn.commit()
        return True
    except Exception as e:
        print(f"Update user info error: {e}")
        return False
    finally:
        conn.close()

def delete_user(username):
    """Delete user"""
    conn = get_connection()
    if not conn:
        return False
    try:
        cursor = conn.cursor()
        sql = "DELETE FROM users WHERE username = %s"
        cursor.execute(sql, (username,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Delete user error: {e}")
        return False
    finally:
        conn.close()

def get_all_users():
    """Get all users"""
    engine = get_sqlalchemy_engine()
    if not engine:
        return pd.DataFrame()
    try:
        df = pd.read_sql('SELECT id, username, role FROM users ORDER BY id', engine)
        return df
    except Exception as e:
        print(f"Get all users error: {e}")
        return pd.DataFrame()
    finally:
        engine.dispose() 